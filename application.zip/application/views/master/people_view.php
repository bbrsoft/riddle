<div class="">
    <div class="page-title" style="padding: 8px">
        <div class="title_left">
            <h1><i class="fa fa-user"></i>  <?php echo $title;?></h1>
        </div>
    </div>
    <?php if($this->session->userdata('role')=='superadmin'): ?>
    <a href="<?php echo base_url()?>people/updatePlayer" class="btn btn-primary pull-right"><i class="fa fa-up-arrow"></i> Update Player</a>
    <?php endif; ?>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>List Data <small>Player</small></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <!-- Notif -->
                <?php $announce = $this->session->userdata('announce') ?>
                <?php if(!empty($announce)): ?>
                    <?php if($announce == 'Berhasil menyimpan data'): ?>
                    <div class="alert alert-success fade in"><?php echo $announce; ?></div>
                    <?php else: ?>
                    <div class="alert alert-danger fade in"><?php echo $announce; ?></div>
                    <?php endif; ?>
                <?php endif; ?>
                <!-- Data -->
                <?php if($total == 0): ?>
                    <div class="alert alert-danger">Tidak ada data</div>
                    <?php else: ?>
                    <table id="datatable" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID Team</th>
                                <th>Birthday</th>
                                <th>Name</th>
                                <th>logo</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($list as $PlayerList):?>
                   
                            <tr>
                                <td><?php echo $no ?></td>
                                <td><?php echo $PlayerList->team_id ?></td>
                                <td><?php echo date('Y-m-d', $PlayerList->birthday); ?></td>
                                <td><?php echo $PlayerList->short_name ?></td>
                                <td><img src="<?php echo $PlayerList->logo ?>" width="20"></td>
                            
                            </tr>
                            <?php $no++; ?>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php if($this->session->userdata('role')=='superadmin'): ?>
    <a href="<?php echo base_url()?>people/updateCoach" class="btn btn-primary pull-right"><i class="fa fa-up-arrow"></i> Update Coach</a>
    <?php endif; ?>

    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>List Data <small>Coach</small></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <!-- Notif -->
                <?php $announce = $this->session->userdata('announce') ?>
                <?php if(!empty($announce)): ?>
                    <?php if($announce == 'Berhasil menyimpan data'): ?>
                    <div class="alert alert-success fade in"><?php echo $announce; ?></div>
                    <?php else: ?>
                    <div class="alert alert-danger fade in"><?php echo $announce; ?></div>
                    <?php endif; ?>
                <?php endif; ?>
                <!-- Data -->
                <?php if($total == 0): ?>
                    <div class="alert alert-danger">Tidak ada data</div>
                    <?php else: ?>
                    <table id="datatable2" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID Team</th>
                                <th>Birthday</th>
                                <th>Name</th>
                                <th>logo</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($list_Coach as $CoachList):?>
                   
                            <tr>
                                <td><?php echo $no ?></td>
                                <td><?php echo $CoachList->team_id ?></td>
                                <td><?php echo date('Y-m-d', $CoachList->birthday); ?></td>
                                <td><?php echo $CoachList->name ?></td>
                                <td><img src="<?php echo $CoachList->logo ?>" width="20"></td>
                            
                            </tr>
                            <?php $no++; ?>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php if($this->session->userdata('role')=='superadmin'): ?>
    <a href="<?php echo base_url()?>people/updateReferee" class="btn btn-primary pull-right"><i class="fa fa-up-arrow"></i> Update Referee</a>
    <?php endif; ?>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>List Data <small>Reffere</small></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <!-- Notif -->
                <?php $announce = $this->session->userdata('announce') ?>
                <?php if(!empty($announce)): ?>
                    <?php if($announce == 'Berhasil menyimpan data'): ?>
                    <div class="alert alert-success fade in"><?php echo $announce; ?></div>
                    <?php else: ?>
                    <div class="alert alert-danger fade in"><?php echo $announce; ?></div>
                    <?php endif; ?>
                <?php endif; ?>
                <!-- Data -->
                <?php if($total == 0): ?>
                    <div class="alert alert-danger">Tidak ada data</div>
                    <?php else: ?>
                    <table id="datatable3" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID country</th>
                                <th>Birthday</th>
                                <th>Name</th>
                                <th>logo</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($list_Reffere as $ReffereList):?>
                   
                            <tr>
                                <td><?php echo $no ?></td>
                                <td><?php echo $ReffereList->country_id ?></td>
                                <td><?php echo date('Y-m-d', $ReffereList->birthday); ?></td>
                                <td><?php echo $ReffereList->name ?></td>
                                <td><img src="<?php echo $ReffereList->logo ?>" width="20"></td>
                            
                            </tr>
                            <?php $no++; ?>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
>