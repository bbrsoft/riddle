<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LiveScore | Live Football Scores</title>
    <link rel="shortcut icon" href="<?php echo base_url() ?>assets/live-assets/img/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
        integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="<?php echo base_url() ?>assets/live-assets/styles.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .LoginForm {
            display: none;
        }
        .LoginForm-active {
            display: block;
        }

        /* CSS untuk membatasi tampilan item */
        .calenderchoose {
            display: none;
        }

        /* CSS untuk menampilkan semua item saat toggle */
        .calenderchoose-active {
            display: block;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .active {
            display: block;
        }
        .tab.active .tab-content {
            display: block;
        }
</style>
    <script src="https://apis.google.com/js/platform.js" async defer></script>
  <meta name="google-signin-client_id" content="1077089742459-1rq1nvfiqbugjdjt501pqmpg7pu5pgqg.apps.googleusercontent.com">

</head>

<body class="bg-livescore-bg text-sm max-w-6xl mx-auto">
        <?php

$comp = null;
$d = null;

if (isset($_GET['comp'])) {
    // Ambil nilai parameter 'comp'
    $comp = $_GET['comp'];	
}

if (isset($_GET['d'])) {
    // Ambil nilai parameter 'comp'
    $d = $_GET['d'];	
}
        ?>
    <!-- TITLE BAR & TOP MENU -->
    <nav class="flex justify-between items-center mt-14 mb-5 mx-3 text-gray-200">
        <div>
            <a href="#" onclick="toggleSlideover()"><img src="<?php echo base_url() ?>assets/live-assets/img/hamburger-menu.svg" alt=""
                    class="inline-block h-4 mr-6"></a>

            <!-- SLIDEOVER CONTENT -->
            <div id="slideover-container" class="w-full h-full fixed inset-0 invisible">
                <div onclick="toggleSlideover()" id="slideover-bg"
                    class="w-full h-full duration-500 ease-out transition-all inset-0 absolute bg-gray-900 opacity-0">
                </div>
                <div onclick="toggleSlideover()" id="slideover"
                    class="w-72 bg-livescore-item h-full absolute left-0 duration-300 ease-out transition-all -translate-x-full">
                    <div class="flex justify-between h-20">
                        <div class="my-auto ml-5">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/livescore-logo.svg" alt="">
                        </div>
                        <div class="cursor-pointer text-gray-300 my-auto mr-5">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </div>
                    </div>
                    <a href="#">
                        <div class="flex text-gray-300 h-10 font-semibold ml-5 mb-2">
                            <div class="my-auto mr-4"><img src="<?php echo base_url() ?>assets/live-assets/img/live.svg" alt="" class="w-6"></div>
                            <div class="my-auto">Sign Up</div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="flex text-gray-300 h-10 font-semibold ml-5 mb-2">
                            <div class="my-auto mr-4"><img src="<?php echo base_url() ?>assets/live-assets/img/settings.svg" alt="" class="w-6"></div>
                            <div class="my-auto">Settings</div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="flex text-gray-300 h-10 font-semibold ml-5 mb-2">
                            <div class="my-auto mr-4"><img src="<?php echo base_url() ?>assets/live-assets/img/what-is-new.svg" alt="" class="w-6"></div>
                            <div class="my-auto">What's new?</div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="flex text-gray-300 h-10 font-semibold ml-5 mb-2">
                            <div class="my-auto mr-4"><img src="<?php echo base_url() ?>assets/live-assets/img/faq.svg" alt="" class="w-6"></div>
                            <div class="my-auto">FAQ</div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="flex text-gray-300 h-10 font-semibold ml-5 mb-2">
                            <div class="my-auto mr-4"><img src="<?php echo base_url() ?>assets/live-assets/img/contact-us.svg" alt="" class="w-6"></div>
                            <div class="my-auto">Contact</div>
                        </div>
                    </a>
                    <div class="absolute inset-x-0 bottom-0">
                        <div class="flex h-20 px-5">
                            <div class="my-auto">
                                <img src="<?php echo base_url() ?>assets/live-assets/img/ls-logo-short.svg" alt="">
                            </div>
                            <div class="text-xs font-semibold ml-4 my-auto">Get instant notifications with the LiveScore
                                app
                            </div>
                        </div>
                        <div class="flex h-20 px-5">
                            <div class="my-auto">
                                <a href="#">
                                    <img src="<?php echo base_url() ?>assets/live-assets/img/app_store.webp" alt="">
                                </a>
                            </div>
                            <div class="my-auto ml-4">
                                <a href="#">
                                    <img src="<?php echo base_url() ?>assets/live-assets/img/google_play.webp" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="h-32 px-5 mt-5">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/cristianoRonaldo.svg" alt="" class="w-32 mx-auto">
                        </div>
                    </div>
                </div>
            </div>

            <a href="#"><img src="<?php echo base_url() ?>assets/live-assets/img/livescore-logo.svg" alt="" class="inline-block"></a>
        </div>
        <div>
            <a href="#" class="text-livescore-active"><img src="<?php echo base_url() ?>assets/live-assets/img/football-scores-active.svg" alt=""
                    class="inline-block h-5 mr-2"> Scores</a>
        </div>
        <div>
            <a href="#"><img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="inline-block h-5 mr-2"> Favourites</a>
        </div>
        <!-- <div>
            <a href="#"><img src="<?php echo base_url() ?>assets/live-assets/img/news-article.svg" alt="" class="inline-block h-5 mr-2"> News</a>
        </div> -->
        <div>
            <a href="#"><img src="<?php echo base_url() ?>assets/live-assets/img/download.svg" alt="" class="inline-block h-5 mr-2"> Get the app <span style="background-color:orange;color:white;border-radius:5px;font-size:12px;padding: 5px 10px">Unready</span></a>
        </div>
        <div>
        <button id="openLogin" class="bg-gray-100 text-livescore-item py-2 px-3 rounded-full">Login</button>
        </div>
       

    </nav>

    <!-- LINE -->
    <div class="border-b border-livescore-border"></div>

    <!-- SPORTS MENU -->
    <div class="flex text-gray-200 mt-4 mx-3 space-x-3">
        <a href="<?php echo base_url() ?>" class="<?php if($segment==''){echo 'bg-gray-100';}?> text-livescore-item py-2 px-3 rounded-full hover:bg-livescore-item-hover">Football</a>
        <!-- <a href="<?php echo base_url().$page ?>/hockey" class="<?php if($segment=='hockey'){echo 'bg-gray-100';}?> bg-livescore-item py-2 px-3 rounded-full hover:bg-livescore-item-hover">Hockey</a>
        <a href="<?php echo base_url().$page ?>/basketball" class="<?php if($segment=='basketball'){echo 'bg-gray-100';}?> bg-livescore-item py-2 px-3 rounded-full hover:bg-livescore-item-hover">Basketball</a>
        <a href="<?php echo base_url().$page ?>/tennis" class="<?php if($segment=='tennis'){echo 'bg-gray-100';}?> bg-livescore-item py-2 px-3 rounded-full hover:bg-livescore-item-hover">Tennis</a>
        <a href="<?php echo base_url().$page ?>/cricket" class="<?php if($segment=='cricket'){echo 'bg-gray-100';}?> bg-livescore-item py-2 px-3 rounded-full hover:bg-livescore-item-hover">Cricket</a>
        <a href="<?php echo base_url().$page ?>/badminton" class="<?php if($segment=='badminton'){echo 'bg-gray-100';}?> bg-livescore-item py-2 px-3 rounded-full hover:bg-livescore-item-hover">Badminton</a> -->
    </div>

    <!-- CONTENT -->
    <div class="flex text-gray-300 mt-4 gap-5 mx-3">

        <!-- LEFT SIDEBAR -->
        <div class="w-60">
            <div class="flex h-auto border border-livescore-border rounded-t-lg p-5">
                <img src="<?php echo base_url() ?>assets/live-assets/img/mobile-search.svg" alt="">
                <input type="text" name="search" id="search-input" placeholder="Search..."
                    class="block w-full bg-livescore-bg ml-3 focus:outline-none focus:ring-0">
            </div>
            <div id="competition-list" class="h-auto text-sm border border-t-0 border-livescore-border py-3 pl-5">
                <?php if (isset($list) && is_array($list)): ?>
                    <?php foreach ($list as $index => $competition): ?>
                        <div class="competition-item mb-2 p-1 rounded-md hover:bg-livescore-item-hover <?php echo $index >= 13 ? 'hidden' : ''; ?>" data-name="<?php echo htmlspecialchars($competition->name, ENT_QUOTES, 'UTF-8'); ?>">
                            <a href="<?php echo base_url().$page; if($tournamentpage!=null){echo '?tournament=';}else if($matchpage!=null){echo '?tournament=';}else{ echo '?comp=';} echo $competition->id;?><?php if(!$d==null){ echo '&d='.$d;}?>">
                                <img src="<?php echo htmlspecialchars($competition->logo, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($competition->name, ENT_QUOTES, 'UTF-8'); ?>" class="inline-block h-3 mr-2">
                                <span style="font-size: 12px;"><?php echo htmlspecialchars($competition->short_name, ENT_QUOTES, 'UTF-8'); ?></span>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No competitions found.</p>
                <?php endif; ?>
            </div>
            <div class="h-auto border border-t-0 border-livescore-border rounded-b-lg p-1 text-center">
                <a href="#" id="see-all-button">See All</a>
            </div>
        </div>


        <!-- Tambahkan ini sebelum penutup tag </body> -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const seeAllButton = document.querySelector('#see-all-button');
                const sidebar = document.querySelector('.w-52');
                const searchInput = document.querySelector('#search-input');
                const competitionItems = document.querySelectorAll('.competition-item');

                if (seeAllButton) {
                    seeAllButton.addEventListener('click', function() {
                        sidebar.classList.toggle('show-all');
                        if (sidebar.classList.contains('show-all')) {
                            seeAllButton.textContent = 'Minimize List';
                        } else {
                            seeAllButton.textContent = 'See All';
                        }
                    });
                }

                if (searchInput) {
                    searchInput.addEventListener('input', function() {
                        const searchTerm = searchInput.value.toLowerCase();
                        let visibleCount = 0;

                        competitionItems.forEach(function(item, index) {
                            const name = item.getAttribute('data-name').toLowerCase();
                            if (name.includes(searchTerm)) {
                                item.style.display = 'block';
                                if (visibleCount >= 13 && !sidebar.classList.contains('show-all')) {
                                    item.classList.add('hidden');
                                } else {
                                    item.classList.remove('hidden');
                                }
                                visibleCount++;
                            } else {
                                item.style.display = 'none';
                            }
                        });
                    });
                }
            });

        
        </script>

        
    <?php if($matchpage!=null){?>
    <!-- MAIN View For Match-->
        <div class="flex-auto mx-3">
            <div class="p-4 bg-black-100 border border-livescore-border rounded-t-lg p-5" >
                <div class="mx-auto" >
                    <ul itemscope="itemscope" itemtype="http://schema.org/BreadcrumbList" class="flex space-x-2 text-sm text-gray-700" >
                        <?php if (isset($match->results) && is_array($match->results)):
                                $foundMatch = false;
                                // var_dump($match->results);

                                foreach ($match->results as $index => $matchs):
                                ?>
                        <li itemprop="itemListElement" itemscope="itemscope" itemtype="<?php echo base_url() ?>" >
                            <a href="<?php echo base_url().$page; ?>" itemprop="item name" class="text-gray-400 hover:underline" > Football Live Score </a>
                            <meta itemprop="position" content="1" >
                        </li>
                        <li class="before:content-['/'] before:mx-2" itemprop="itemListElement" itemscope="itemscope" itemtype="<?php echo base_url() ?>" >
                            <a href="<?php echo base_url().$page; ?>?tournament=<?php echo $matchs->competition_id;?>" itemprop="item name" class="text-gray-400 hover:underline" > <?php echo $tournament_competition;?> </a>
                            <meta itemprop="position" content="2" >
                        </li>
                        <li class="before:content-['/'] before:mx-2" itemprop="itemListElement" itemscope="itemscope" itemtype="http://schema.org/ListItem" >
                            <span itemprop="name" class="font-semibold text-white font-size-xs" > <?php echo $home_team;?> vs <?php echo $away_team;?> live score, prediction (<?php echo date('Y-m-d',$matchs->match_time);?>) </span>
                            <meta itemprop="position" content="3" >
                        </li>
                        <?php endforeach;?>
                        <?php endif;?>
                    </ul>
                </div>
            </div>

            <div class="bg-black-100 flex flex-col items-center text-gray-800"  >
                
                <?php if (isset($match->results) && is_array($match->results)):
                    $foundMatch = false;
                    // var_dump($match->results);

                    foreach ($match->results as $index => $matchs):
                ?>
                <div class="flex items-center space-x-2 mt-4" >
                    <i class="iconfont icon-weishoucang" ></i>
                    <a href="<?php echo base_url().$page; ?>?tournament=<?php echo $matchs->competition_id;?>" class="text-gray-400 hover:underline" ><?php echo $tournament_competition;?> </a>
                    <span class="text-gray-400" >-</span>
                    <span class="text-gray-400">Round <?php echo $matchs->round->round_num;?></span>
                    <span class="text-gray-400" >/</span>
                    <span class="text-gray-400" ><?php
                        // Pastikan $matchs->match_time adalah Unix timestamp
                        $timestamp = $matchs->match_time;

                        // Format tanggal
                        $date = date('M d Y', $timestamp);

                        // Format waktu
                        $time = date('h:i A', $timestamp);

                        // Format hari
                        $day = date('l', $timestamp);

                        // Tampilkan hasil
                        echo $time  . ' ' . $date . ' ' . $day;
                        ?>
                        
                    </span>
                </div>

                <div class="flex justify-between items-center mt-4" >
                    <div class="flex flex-col items-center" >
                        <div class="text font-medium text-center" >
                            <a href="/team-atletico-tucuman/69759i39jnank23" class="text-gray-400" > <?php echo $home_team;?> </a>
                        </div>
                        <a href="/team-atletico-tucuman/69759i39jnank23" class="mt-2" >
                            <img alt="Atletico Tucuman" title="Atletico Tucuman" src="<?php echo $home_flag;?>" itemprop="logo" class="w-10 h-10" >
                        </a>
                        <i class="iconfont icon-weishoucang mt-2" ></i>
                    </div>
                    <div class="flex flex-col items-center mx-4" >
                        <div class="font-bold text-lg" >
                            <span class="text-gray-400"><?php echo $matchs->home_scores[0];?></span>
                        </div>
                        <div class="flex flex-col items-center text-center mx-4" >
                            <div class="h-16 mb-1" >
                                <span class="text-red-600" >
                                    <span ><?php
                                    date_default_timezone_set('Asia/Jakarta'); // Set timezone sesuai kebutuhan

                                    // Misalkan $matchs->match_time adalah Unix timestamp
                                    $match_time = $matchs->match_time;
                                    $current_time = time(); // Waktu saat ini dalam Unix timestamp

                                    // Durasi pertandingan dalam menit (misalnya 90 menit)
                                    $match_duration = 90 * 60; // 90 menit dalam detik

                                    // Waktu akhir pertandingan
                                    $end_time = $match_time + $match_duration;

                                    if ($current_time >= $end_time) {
                                        // Pertandingan sudah selesai
                                        echo "FT";
                                    } else {
                                        // Pertandingan belum selesai
                                        // Hitung waktu yang tersisa dalam menit
                                        $remaining_time = ceil(($end_time - $current_time) / 60);
                                        echo $remaining_time;
                                    }
                                    ?>
                                    </span>
                                    <span  class="animate-pulse">'</span>
                                </span>
                            </div>
                            <div class="text-sm text-gray-500" > HT 0-0 </div>
                        </div>
                        <div class="font-bold text-lg" >
                            <span class="text-gray-400"><?php echo $matchs->away_scores[0];?></span>
                        </div>
                    </div>
                    <div class="flex flex-col items-center" >
                        <i class="iconfont icon-weishoucang mb-2" ></i>
                        <a href="/team-ca-platense/ezk96inx15twkn5" class="mt-2" >
                            <img alt="CA Platense" title="CA Platense" src="<?php echo $away_flag;?>" itemprop="logo" class="w-10 h-10" >
                        </a>
                        <div class="text font-medium text-center mt-2" >
                            <a href="/team-ca-platense/ezk96inx15twkn5" class="text-gray-400"> <?php echo $away_team;?> </a>
                        </div>
                    </div>
                </div>

                <?php endforeach;?>
                        <?php endif;?>
            </div>

            <div class="flex justify-between tab-bar"  >
                <div class="content-box" >
                    <div class="child flex space-x-4" >
                        <button id="tab-overview" onclick="selectTab('tab-overview')" class="tab active border-b-2 border-blue-500">Overview</button>
                        <button id="tab-h2h" onclick="selectTab('tab-h2h')" class="tab border-b-2 border-transparent hover:border-blue-500">H2H</button>
                        <?php if(isset($match_data_lineUp)){?>
                            <button id="tab-lineup" onclick="selectTab('tab-lineup')" class="tab border-b-2 border-transparent hover:border-blue-500">Line Up</button>
                        <?php } ?>
                    </div>
                </div>
            </div>

            <div  id="tab-content-overview" class="tab-content p-4 bg-black-100 border border-livescore-border rounded-t-lg p-5">
                <div class="mx-auto" >
                    <div class="flex odds" >
                        <div class="table flex-1 oddType" >
                            <div class="head" >
                            <i class="iconfont icon-xiala" ></i>
                            <div class="oddContent" >
                                <img  src="https://img1.aiscore.com/other/fe8aec51afeb2de633c9.png" width="30px" alt="#" class="oddType">
                                <!---->
                            </div>
                            <!---->
                            </div>
                            <div class="row box" style="position:relative;border-bottom:1px solid #EEEEEE;border-left-color:#2196F3;" >
                            <span class="flex align-center" >
                                <!----> Opening odds
                            </span>
                            </div>
                            <div class="row box" style="position: relative; border-bottom: medium; border-left-color: rgb(255, 186, 90);" >
                            <span class="flex align-center" >
                                <!----> Pre-match odds
                            </span>
                            <!---->
                            <!---->
                            <!---->
                            <!---->
                            </div>
                            <div class="row box" style="position: relative; border-bottom: 1px solid rgb(238, 238, 238); border-left-color: rgb(93, 180, 0);" >
                            <span class="flex align-center" >
                                <img src="https://static.aiscore.com/_nuxt/img/live.c4bb762.gif" alt="#" width="20px" > In-play odds </span>
                            <!---->
                            <!---->
                            <!---->
                            <!---->
                            </div>
                        </div>
                        <div class="table flex-1 eu" >
                            <div class="row flex" >
                            <span class="col flex w-1/4">1</span>
                            <span class="col flex w-1/4">X</span>
                            <span class="col flex w-1/4">2</span>
                            <!---->
                            <div class="oddContent" >
                                <!---->
                                <!---->
                            </div>
                            <!---->
                            </div>
                            <div class="row box" style="position:relative;border-bottom:1px solid #EEEEEE;border-left-color:#2196F3;" >
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            <!---->
                            <!---->
                            <!---->
                            </div>
                            <div class="row box" style="position: relative; border-bottom: medium; border-left-color: rgb(255, 186, 90);" >
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            <!---->
                            <!---->
                            <!---->
                            </div>
                            <div class="row box" style="position: relative; border-bottom: 1px solid rgb(238, 238, 238); border-left-color: rgb(93, 180, 0); " >
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            <!---->
                            <!---->
                            <!---->
                            </div>
                        </div>
                        <div class="table flex-1 asia" >
                            <div class="head" >
                            <!---->
                            <span >Asian Handicap</span>
                            <!---->
                            <!---->
                            <div class="oddContent" >
                                <!---->
                                <!---->
                            </div>
                            <!---->
                            </div>
                            <div class="row box" style="position:relative;border-bottom:1px solid #EEEEEE;border-left-color:#2196F3;" >
                            <!---->
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            <!---->
                            <!---->
                            </div>
                            <div class="row box" style="position: relative; border-bottom: medium; border-left-color: rgb(255, 186, 90); " >
                            <!---->
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            <!---->
                            <!---->
                            </div>
                            <div class="row box" style="position: relative; border-bottom: 1px solid rgb(238, 238, 238); border-left-color: rgb(93, 180, 0); " >
                            <!---->
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            <!---->
                            <!---->
                            </div>
                        </div>
                        <div class="table flex-1 bs" >
                            <div class="head" >
                            <span >Goals</span>
                            <span >Over</span>
                            <span >Under</span>
                            <!---->
                            <div class="oddContent" >
                                <!---->
                                <!---->
                            </div>
                            <!---->
                            </div>
                            <div class="row box" style="position:relative;border-bottom:1px solid #EEEEEE;border-left-color:#2196F3;" >
                            <!---->
                            <!---->
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            <!---->
                            </div>
                            <div class="row box" style="position: relative; border-bottom: medium; border-left-color: rgb(255, 186, 90); " >
                            <!---->
                            <!---->
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            <!---->
                            </div>
                            <div class="row box" style="position: relative; border-bottom: 1px solid rgb(238, 238, 238); border-left-color: rgb(93, 180, 0); " >
                            <!---->
                            <!---->
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            <!---->
                            </div>
                        </div>
                        <div class="table flex-1 corner" >
                            <div class="head" >
                            <span >Corners</span>
                            <span >Over</span>
                            <span >Under</span>
                            <!---->
                            <div class="oddContent" >
                                <!---->
                                <!---->
                            </div>
                            <!---->
                            </div>
                            <div class="row box" style="position:relative;border-bottom:1px solid #EEEEEE;border-left-color:#2196F3;" >
                            <!---->
                            <!---->
                            <!---->
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            </div>
                            <div class="row box" style="position: relative; border-bottom: medium; border-left-color: rgb(255, 186, 90); " >
                            <!---->
                            <!---->
                            <!---->
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            </div>
                            <div class="row box" style="position: relative; border-bottom: 1px solid rgb(238, 238, 238); border-left-color: rgb(93, 180, 0); " >
                            <!---->
                            <!---->
                            <!---->
                            <!---->
                            <div class="row flex w100" >
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                                <div class="col cur-pointer flex w-1/4" >
                                <span class=""> - </span>
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>
                </div>

                <div class="child flex space-x-4" >
                    <iframe width="500" height="500" allowfullscreen="allowfullscreen" webkitallowfullscreen="true" mozallowfullscreen="true" src="//widgets.thesports01.com/en/3d/football?profile=74rekh26eseunr0&amp;id=4054410"></iframe></div>
            
            </div>

            <div id="tab-content-h2h" class="tab-content p-4 bg-black-100 border border-livescore-border rounded-t-lg p-5 hidden">
                <div class="allBox">
                    <div class="headerBox flex justify-between items-center">
                        <p>
                        <span>H2H</span>
                        </p>
                    </div>
                    <div class="screenBox flex justify-between items-center">
                        <p class="mr-4">
                        <span class="font-bold">Home</span>
                        <span class="font-bold">- <?php echo $home_team;?></span>

                        </p>
                        <p>
                        <span>This league</span>
                        </p>
                    </div>
                    <div class="infoBox flex items-center space-x-5 m-2">
                        <span class="flex items-center space-x-1">
                        <span class="round flex items-center justify-center loser bg-red-500 border border-black rounded-full" style="padding:1px 3px;">W</span>
                        <span class="text">X2</span>
                        </span>
                        <span class="flex items-center space-x-1">
                        <i class="iconfont icon-pingju"></i>
                        <span class="text">X0</span>
                        </span>
                        <span class="flex items-center space-x-1">
                        <span class="round flex items-center justify-center loser bg-green-500 border border-black rounded-full" style="padding:1px 7px;">L</span>
                        <span class="text">X1</span>
                        </span>
                        <span class="infoItem flex items-center space-x-1">
                        <img src="https://img1.aiscore.com/country/1552909490206875.png!w30" width="20" alt="#">
                        <span class="text">2.7 - 1.7 per game</span>
                        </span>
                    </div>
                    <div class="matchContent m-2">
                        <p class="header flex justify-between items-center">
                            <span class="comp flex items-center space-x-1">
                                <img src="<?php echo $home_flag;?>" width="20" alt="#">
                                <span class="country flex items-center"><?php echo $country_name;?>:</span>
                                <span class="flex items-center"><?php echo $tournament_competition;?></span>
                            </span>
                            <span class="flex items-center space-x-2 ml-auto">
                                <span class="score flex items-center">HT</span>
                                <span class="score flex items-center">FT</span>
                            </span>
                        </p>

                        <ul class="matchBox space-y-2">
                        <?php 
                            
                            foreach ($match_data_h2h->results->history->vs as $index => $historyVS):
                        ?>
                            <li itemscope itemtype="http://schema.org/SportsEvent" class="grid grid-cols-2 gap-4">
                                <div class="flex flex-col items-start">
                                    <p class="collect flex items-center justify-center m-2">
                                    <span class="round flex items-center justify-center loser bg-green-500 border border-black rounded-full" style="padding:1px 7px;">L</span> 
                                    <?php
                                       
                                            if (is_array($historyVS[3])) {
                                                // Periksa apakah elemen ke-3 ada dalam array tersebut
                                                if (isset($historyVS[3])) {
                                                    $date_string = $historyVS[3];
                                                } else {
                                                    // Tangani kasus di mana elemen ke-3 tidak ada
                                                    $date_string = "";
                                                }
                                            } else {
                                                // Tangani kasus di mana $historyVS[$index] bukan array
                                                $date_string = "";
                                            } 
                                            $timestamp = strtotime($date_string);
                                            $formatted_date = date('l, F j, Y', $timestamp);
                                            echo '- '.$formatted_date;
                                        
                                        ?>
                                    </p>
                                </div>
                                <div class="flex flex-col items-start m-4">
                                    
                                    <p class="row flex">
                                        <div class="flex items-center justify-between w-full">
                                        <?php foreach ($listteam as $index => $team){ 
                                                if($team->id==$historyVS[5][0]){
                                            ?>
                                            <a href="/match-colo-colo-cerro-porteno/ezk96ixm9njt1kn" target="_blank" itemprop="url" class="flex items-center">
                                                <span itemprop="homeTeam" itemscope itemtype="http://schema.org/SportsTeam" class="teamBoxItem flex items-center">
                                                    <img src="<?php echo $team->logo; ?>" alt="Colo Colo Logo" itemprop="logo" width="30px">
                                                    <span itemprop="name" class="teamName ml-2"><?php echo $team->name; ?></span>
                                                </span>
                                            </a>
                                            <div class="flex items-center">
                                                <span class="flex items-center justify-center mx-2 font-bold"><?php echo $historyVS[5][2]?></span>
                                                <span class="flex items-center justify-center font-bold"><?php echo $historyVS[5][3]?></span>
                                            </div>
                                            <?php 
                                            break;
                                            }
                                        } ?>
                                        </div>
                                    </p>

                                    <p class="row flex">
                                        <div class="flex items-center justify-between w-full">
                                        <?php foreach ($listteam as $index => $team){ 
                                                if($team->id==$historyVS[6][0]){
                                            ?>
                                            <a href="/match-colo-colo-cerro-porteno/ezk96ixm9njt1kn" target="_blank" itemprop="url" class="flex items-center">
                                                <span itemprop="homeTeam" itemscope itemtype="http://schema.org/SportsTeam" class="teamBoxItem flex items-center">
                                                <img src="<?php echo $team->logo; ?>" alt="Cerro Porteno Logo" itemprop="logo" width="30px">
                                                    <span itemprop="name" class="teamName ml-2"><?php echo $team->name; ?></span>
                                                </span>
                                            </a>
                                            <div class="flex items-center">
                                                <span class="flex items-center justify-center mx-2 font-bold"><?php echo $historyVS[6][2]?></span>
                                                <span class="flex items-center justify-center font-bold"><?php echo $historyVS[6][3]?></span>
                                            </div>
                                            <?php 
                                            break;
                                            }
                                        } ?>
                                        </div>
                                    </p>
                                  
                                </div>
                            </li>

                            <?php 
                            endforeach;
                        ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div id="tab-content-lineup" class="tab-content p-4 bg-black-100 border border-livescore-border rounded-t-lg p-5 hidden">
                <?php 
                  //  var_dump($match_data_lineUp);
                ?>

                <div class="head">
                    <div class="row flex">
                        <div class="col flex" >
                            <a target="_self" href="#" class="ml-xs cursor-pointer" >
                            <img src="<?php echo $home_flag;?>" alt="Olympiakos Piraeus" title="Olympiakos Piraeus" class="w-8" >
                            </a>
                            <div class="desc ml-xs" >
                            <a target="_self" href="#" class="name text-gray-700 text-sm cursor-pointer" ><?php echo $home_couch_country;?></a>
                            <div class="sub text-xs mt-1" >
                                <span class="text-blue-500" ><?php echo $home_couch;?></span>
                                <span class="text-gray-600 ml-1" >Coach</span>
                            </div>
                            </div>
                        </div>
                        <div class="col flex w-1/3" >
                            <span></span>
                        </div>
                        <div class="col flex" >
                            <a target="_self" href="#" class="ml-xs cursor-pointer" >
                            <img src="<?php echo $away_flag;?>" alt="Olympiakos Piraeus" title="Olympiakos Piraeus" class="w-8" >
                            </a>
                            <div class="desc ml-xs" >
                            <a target="_self" href="#" class="name text-gray-700 text-sm cursor-pointer" ><?php echo $away_couch_country;?></a>
                            <div class="sub text-xs mt-1" >
                                <span class="text-blue-500" ><?php echo $away_couch;?></span>
                                <span class="text-gray-600 ml-1" >Coach</span>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="row flex">
                        
                        <div class="col fs-12 pr-15 pl-15" >
                        <?php foreach ($match_data_lineUp->results->lineup->home as $index => $player_home):
                        ?>
                            <div class="flex flex-1 items-center" >
                                <div class="text-b shirtNumber" ><?php echo $player_home->shirt_number;?></div>
                                <a href="/player-stevan-jovetic/ndkz6izryjiwq3z" class="ml-2 cursor-pointer" >
                                    <img src="<?php echo $player_home->logo;?>" alt="S. Jovetić" title="S. Jovetić" class=" w-6 rounded-full player-logo" >
                                </a>
                                <div class="desc ml-2" >
                                    <a href="/player-stevan-jovetic/ndkz6izryjiwq3z" class="name text-gray-700 cursor-pointer" ><?php echo $player_home->name;?></a>
                                    <div class="sub mt-1" ><span class="text-gray-600" ><?php echo $player_home->position;?></span></div>
                                </div>
                                <div class="ml-2 flex flex-col items-center" >
                                    <div class="h-16" >
                                        <svg aria-hidden="true" class="w-16 h-16" ><use xlink:href="#icon-substitution" ></use></svg>
                                    </div>
                                    <div class="text-blue-500 fs-12" ></div>
                                </div>
                                <div class="ml-2 flex flex-col items-center" >
                                    <div class="h-16" >
                                        <svg aria-hidden="true" class="w-16 h-16" ><use xlink:href="#icon-yellow-card" ></use></svg>
                                    </div>
                                    <div class="text-blue-500 fs-12" ></div>
                                </div>
                            </div>
                            <div class="right text-white text-center" style="background-color:#FFAE0F;" ><div ><?php echo $player_home->rating;?></div></div>
                            <?php endforeach;?>
                        </div>
                        
                        <div class="col flex w-1/3" >
                            <span></span>
                        </div>
                        <div class="col fs-12 pr-15 pl-15" >
                        <?php 
                            
                            foreach ($match_data_lineUp->results->lineup->away as $index => $player_away):
                        ?>
                            <div class="flex flex-1 items-center" >
                                <div class="text-b shirtNumber" ><?php echo $player_away->shirt_number;?></div>
                                <a href="/player-alfred-duncan/8lk2di5oo5co736" class="ml-2 cursor-pointer" >
                                    <img src="<?php echo $player_away->logo;?>" alt="A. Duncan" title="A. Duncan" class="w-6 rounded-full player-logo" >
                                </a>
                                <div class="desc ml-2" >
                                    <a href="/player-alfred-duncan/8lk2di5oo5co736" class="name text-gray-700 cursor-pointer" ><?php echo $player_away->name;?></a>
                                    <div class="sub mt-1" ><span class="text-gray-600" ><?php echo $player_away->position;?></span></div>
                                </div>
                                <div class="ml-2 flex flex-col items-center" >
                                    <div class="h-16" >
                                        <svg aria-hidden="true" class="w-16 h-16" ><use xlink:href="#icon-substitution" ></use></svg>
                                    </div>
                                    <div class="text-blue-500 fs-12" ></div>
                                </div>
                            </div>
                            <div class="right text-white text-center" style="background-color:#FFAE0F;" ><div ><?php echo $player_away->rating;?></div></div>
                            <?php endforeach;?>
                        </div>
                        
                    </div>

                </div>

            </div>

            <script>

                var selectedTabContent = document.getElementById('tab-content-overview');
                selectedTabContent.classList.add('active');

                function selectTab(tabId) {
                    // Menghapus kelas 'active' dari semua elemen tab
                    var tabs = document.querySelectorAll('.tab');
                    tabs.forEach(function(tab) {
                        tab.classList.remove('active');
                    });

                    // Menambahkan kelas 'active' ke tab yang diklik
                    var selectedTab = document.getElementById(tabId);
                    selectedTab.classList.add('active');

                    // Menampilkan konten yang sesuai dengan tab yang dipilih
                    var tabContents = document.querySelectorAll('.tab-content');
                    tabContents.forEach(function(content) {
                        content.classList.remove('active');
                    });
                    var selectedTabContent = document.getElementById('tab-content-' + tabId.replace('tab-', ''));
                    selectedTabContent.classList.add('active');
                }

            </script>

        </div>
    <?php }elseif($tournamentpage!=null){?>
    <!-- MAIN View for Tournament-->
        <div class="flex-auto">
            <?php if (isset($match->results) && is_array($match->results)):
                $foundMatch = false;
                foreach ($match->results as $index => $matchs):
            ?>
            <div class="p-4 bg-black-100 border border-livescore-border rounded-t-lg p-5" >
                    <div class="mx-auto" >
                        <ul itemscope="itemscope" itemtype="http://schema.org/BreadcrumbList" class="flex space-x-2 text-sm text-gray-700" >
                            
                            <li itemprop="itemListElement" itemscope="itemscope" itemtype="<?php echo base_url() ?>" >
                                <a href="<?php echo base_url().$page; ?>" itemprop="item name" class="text-gray-400 hover:underline" > Football Live Score </a>
                                <meta itemprop="position" content="1" >
                            </li>
                            <li class="before:content-['/'] before:mx-2" itemprop="itemListElement" itemscope="itemscope" itemtype="<?php echo base_url() ?>" >
                                <a href="<?php echo base_url().$page; ?>?tournament=<?php echo $tournamentpage;?>" itemprop="item name" class="text-gray-400 hover:underline" > <?php echo $matchs->name ? $matchs->name : $matchs->short_name;?> </a>
                                <meta itemprop="position" content="2" >
                            </li>
                            <li class="before:content-['/'] before:mx-2" itemprop="itemListElement" itemscope="itemscope" itemtype="http://schema.org/ListItem" >
                                <span itemprop="name" class="font-semibold text-white font-size-xs" >  live score, Schedule, Standings   </span>
                                <meta itemprop="position" content="3" >
                            </li>
                            
                        </ul>
                    </div>
                </div>
                <div class="bg-black-100 flex flex-col items-center text-gray-800"  >

                    <div class="p-l flex-1 flex align-center" >
                        <div class="flex flex-1 align-center" style="height: 88px;" >
                            <img src="<?php echo $matchs->logo; ?>"  title="League" class="team-logo" >
                            <div class="pl-15 pr-15" >
                                <div class="fs-24 font-500 flex" >
                                    <span class="text-white" style="max-width: 330px;" ><?php echo $matchs->name ? $matchs->name : $matchs->short_name;?></span>
                                    <span class="flex justify-center align-center mr-10" >
                                        <svg aria-hidden="true" class="collect-btn" >
                                            <use xlink:href="#icon-shoucang" ></use>
                                        </svg>
                                    </span>
                                </div>
                                <div class="mt-8 flex" >
                                    <div class="country-logo" >
                                        <img src="<?php echo $flag_country_compotitiion;?>" />
                                    </div>
                                    <span class="ml-xs fs-14 text-white" style="line-height: 24px;" ><?php echo $country_compotitiion;?></span>
                                    <div  class="el-select select-transfers-year ml-12 el-select--mini">
                                        <div class="el-input el-input--mini el-input--suffix">
                                            <!---->
                                            <!---->
                                            <span class="el-input__suffix">
                                                <span class="el-input__suffix-inner">
                                                    <i class="el-select__caret el-input__icon el-icon-arrow-up"></i>
                                                </span>
                                            </span>
                                        </div>
                                        <div class="el-select-dropdown el-popper" style="display: none; min-width: 74px;">
                                            <div class="el-scrollbar" style="">
                                                <div class="el-select-dropdown__wrap el-scrollbar__wrap el-scrollbar__wrap--hidden-default">
                                                    <ul class="el-scrollbar__view el-select-dropdown__list">
                                                        <!---->
                                                        <li  class="el-select-dropdown__item selected">
                                                            <span>23/24</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>22/23</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>21/22</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>20/21</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>19/20</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>18/19</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>17/18</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>16/17</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>15/16</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>14/15</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>13/14</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>12/13</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>11/12</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>10/11</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>09/10</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>08/09</span>
                                                        </li>
                                                        <li  class="el-select-dropdown__item">
                                                            <span>07/08</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="el-scrollbar__bar is-horizontal">
                                                    <div class="el-scrollbar__thumb" style="transform: translateX(0%);"></div>
                                                </div>
                                                <div class="el-scrollbar__bar is-vertical">
                                                    <div class="el-scrollbar__thumb" style="transform: translateY(0%);"></div>
                                                </div>
                                            </div>
                                            <!---->
                                        </div>
                                    </div>
                                </div>
                                </div>
                                <div class="flex flex-col fs-12 pl-15 ml-l" style="border-left: 1px dashed #DCDDDF;" >
                                    <div class="flex mb-xxs" >
                                        <div class="text-white font-300" style="width: 140px;" >Title holder :</div>
                                        <a href="/team-qarabag/59gklzi8rpc17xd" class="text-white w-o-h cur-pointer" style="max-width: 240px;" >Qarabag</a>
                                    </div>
                                    <div class="flex" >
                                        <div class="text-white font-300 cur-pointer" style="width: 140px;" >Most valuable player :</div>
                                        <div class="color-333 w-o-h" style="max-width: 240px;" >
                                            <a href="/player-kei-chinen/g6763i09lrs97ry" class="text-white" >Kei Chinen € 1.4M</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flex flex-col fs-12 border">
                            <div class="bg-white justify-between text-center items-center top" >
                                <div >23-24 PREM STATS</div>
                            </div>
                            <div class="flex flex-1 pl-4 pr-4 box-border justify-between text-center items-center">
                                <div class="flex-1">
                                    <div class="font-light mb-1 text-white">Players</div>
                                    <div class="font-medium text-white">338</div>
                                </div>
                                <div class="flex-1">
                                    <div class="font-light mb-1 text-white transform origin-left">Foreign players</div>
                                    <div class="font-medium text-white">147</div>
                                </div>
                                <div class="flex-1">
                                    <div class="font-light mb-1 text-white">Number of teams</div>
                                    <div class="font-medium text-white">10</div>
                                </div>
                                <div class="flex-1">
                                    <div class="font-light mb-1 text-white">Total market value</div>
                                    <div class="font-medium text-pink-500">€ 74.35M</div>
                                </div>
                            </div>
                        </div>
                </div>
                <?php endforeach;?>
                <?php endif;?>
                <div class="flex justify-between tab-bar"  >
                    <div class="content-box" >
                        <div class="child flex space-x-4" >
                            <a href="/tournament-azerbaijan-premier-league/2j374oirla4qo6d" rel="" target="_self" class="tab active" style="display:;" >
                                Overview
                            </a><a href="/tournament-azerbaijan-premier-league/2j374oirla4qo6d/schedule" rel="" target="_self" class="tab" style="display:;" >
                                Schedule
                            </a><a href="/tournament-azerbaijan-premier-league/2j374oirla4qo6d/standings" rel="" target="_self" class="tab" style="display:;" >
                                Standings
                            </a><a href="/tournament-azerbaijan-premier-league/2j374oirla4qo6d/stats" rel="" target="_self" class="tab" style="display:;" >
                                Stats
                            </a><a href="/tournament-azerbaijan-premier-league/2j374oirla4qo6d/transfers" rel="" target="_self" class="tab" style="display:;" >
                                Transfer
                            </a><a href="/tournament-azerbaijan-premier-league/2j374oirla4qo6d/archive" rel="" target="_self" class="tab" style="display:;" >
                                Champions
                            </a>
                        </div>
                    </div>
                </div>
                <div class="p-4 bg-black-100 border border-livescore-border rounded-t-lg p-5" >
                    <div class="title flex justify-between" >
                        <span class="color-p font-500 w-o-h" > Azerbaijan Premier League Matches 23-24 </span>
                        <span class="color-999 fs-12" ></span>
                        <!---->
                        </div>
                        <div class="fs-12 color-666 pl-15 pr-15 pb-xxs"   >
                        <div class="w100" >
                            <div class="stage-box mt-15" >
                                <span class="stage pl-15 pr-15 border-box active" >League</span>
                            </div>
                            <div class="flex flex-wrap mb-4 gap-2">
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">1</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">2</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">3</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">4</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">5</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">6</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">7</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">8</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">9</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">10</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">11</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">12</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">13</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">14</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">15</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">16</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">17</div>
                                <div class="flex justify-center items-center bg-blue-500 text-white rounded-sm p-2 hover:bg-blue-600">18</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">19</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">20</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">21</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">22</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">23</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">24</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">25</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">26</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">27</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">28</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">29</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">30</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">31</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">32</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">33</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">34</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">35</div>
                                <div class="flex justify-center items-center bg-gray-200 text-gray-700 rounded-sm p-2 hover:bg-gray-300">36</div>
                            </div>



                            <!---->
                            <div class="body" >
                                <div data-matchstatus="3" itemscope="itemscope" itemtype="http://schema.org/SportsEvent" class="flex text-sm text-gray-800">
                                    <span itemprop="startDate" class="flex items-center justify-center w-1/6">22 Dec 19:00</span>
                                    <a href="/team-fk-gilan-gabala/34kgmi2ep8f8ko9" target="_blank" itemprop="homeTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-end text-blue-600">
                                        <span itemprop="name">FK Gilan Gabala</span>
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/01b36d0eae3771391455661b45834805.jpg!w30" alt="FK Gilan Gabala" title="FK Gilan Gabala" class="team-logo ml-3">
                                    </a>
                                    <a itemprop="url" href="/match-fk-gilan-gabala-sabah-baku/xvkjoi0m2vrc879" target="_blank" class="flex items-center justify-center w-1/12 text-gray-800">1 - 0</a>
                                    <a href="/team-sabah-baku/8lk2di5514a3736" target="_blank" itemprop="awayTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-start text-blue-600">
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/be41df36cb4153c32d4dcf36489d0b80.png!w30" alt="Sabah Baku" title="Sabah Baku" class="team-logo mr-3">
                                        <span itemprop="name">Sabah Baku</span>
                                    </a>
                                    <meta itemprop="name" content="FK Gilan Gabala vs Sabah Baku">
                                    <meta itemprop="url" content="https://www.aiscore.com/match-fk-gilan-gabala-sabah-baku/xvkjoi0m2vrc879">
                                    <meta itemprop="startDate" content="2023-12-22T08:00:00-04:00">
                                    <meta itemprop="eventStatus" content="https://schema.org/EventScheduled">
                                    <meta itemprop="description" content="2023-12-22T08:00:00-04:00, FK Gilan Gabala vs Sabah Baku in the Azerbaijan Premier League">
                                    <meta itemprop="location" content="Gabala City Stadium">
                                    <meta itemprop="Organization" content="Azerbaijan Premier League">
                                    <a rel="nofollow" href="/match-fk-gilan-gabala-sabah-baku/xvkjoi0m2vrc879" target="_blank" class="flex items-center justify-center w-1/6 text-gray-800">
                                        <div class="w-full text-right pr-8">
                                            <span class="iconfont icon-lujingbeifen text-xs text-gray-600 transform scale-75"></span>
                                        </div>
                                    </a>
                                </div>

                                <div data-matchstatus="3" itemscope="itemscope" itemtype="http://schema.org/SportsEvent" class="flex text-sm text-gray-800">
                                    <span itemprop="startDate" class="flex items-center justify-center w-1/6">23 Dec 21:30</span>
                                    <a href="/team-standard-sumgayit/0ndkz6iwjjaeq3z" target="_blank" itemprop="homeTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-end text-blue-600">
                                        <span itemprop="name">Standard Sumgayit</span>
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/46e02b8dea22b2951976d1262dd0279f.png!w30" alt="Standard Sumgayit" title="Standard Sumgayit" class="team-logo ml-3">
                                    </a>
                                    <a itemprop="url" href="/match-standard-sumgayit-sabail-fc/zrkn6ivl13lfwql" target="_blank" class="flex items-center justify-center w-1/12 text-gray-800">1 - 0</a>
                                    <a href="/team-sabail-fc/g6763ido9lip7ry" target="_blank" itemprop="awayTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-start text-blue-600">
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/e8ff74bbde41ecfd522e50ad4dd8e7b5.png!w30" alt="Sabail FC" title="Sabail FC" class="team-logo mr-3">
                                        <span itemprop="name">Sabail FC</span>
                                    </a>
                                    <meta itemprop="name" content="Standard Sumgayit vs Sabail FC">
                                    <meta itemprop="url" content="https://www.aiscore.com/match-standard-sumgayit-sabail-fc/zrkn6ivl13lfwql">
                                    <meta itemprop="startDate" content="2023-12-23T10:30:00-04:00">
                                    <meta itemprop="eventStatus" content="https://schema.org/EventScheduled">
                                    <meta itemprop="description" content="2023-12-23T10:30:00-04:00, Standard Sumgayit vs Sabail FC in the Azerbaijan Premier League">
                                    <meta itemprop="location" content="Kapital Bank Arena">
                                    <meta itemprop="Organization" content="Azerbaijan Premier League">
                                    <a rel="nofollow" href="/match-standard-sumgayit-sabail-fc/zrkn6ivl13lfwql" target="_blank" class="flex items-center justify-center w-1/6 text-gray-800">
                                        <div class="w-full text-right pr-8">
                                            <span class="iconfont icon-lujingbeifen text-xs text-gray-600 transform scale-75"></span>
                                        </div>
                                    </a>
                                </div>

                                <div data-matchstatus="3" itemscope="itemscope" itemtype="http://schema.org/SportsEvent" class="flex text-sm text-gray-800">
                                    <span itemprop="startDate" class="flex items-center justify-center w-1/6">24 Dec 19:00</span>
                                    <a href="/team-fc-neftci-baku/r8lk2di24wi3736" target="_blank" itemprop="homeTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-end text-blue-600">
                                        <span itemprop="name">FC Neftci Baku</span>
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/2d9ea2234c3ada82b3d0355791c45669.png!w30" alt="FC Neftci Baku" title="FC Neftci Baku" class="team-logo ml-3">
                                    </a>
                                    <a itemprop="url" href="/match-fc-neftci-baku-fk-kapaz-ganca/m2q15ipe842ie76" target="_blank" class="flex items-center justify-center w-1/12 text-gray-800">2 - 0</a>
                                    <a href="/team-fk-kapaz-ganca/l6kegizro0fg75d" target="_blank" itemprop="awayTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-start text-blue-600">
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/6e7d0a85acba4a7748913610852cc9cc.png!w30" alt="FK Kapaz Ganca" title="FK Kapaz Ganca" class="team-logo mr-3">
                                        <span itemprop="name">FK Kapaz Ganca</span>
                                    </a>
                                    <meta itemprop="name" content="FC Neftci Baku vs FK Kapaz Ganca">
                                    <meta itemprop="url" content="https://www.aiscore.com/match-fc-neftci-baku-fk-kapaz-ganca/m2q15ipe842ie76">
                                    <meta itemprop="startDate" content="2023-12-24T08:00:00-04:00">
                                    <meta itemprop="eventStatus" content="https://schema.org/EventScheduled">
                                    <meta itemprop="description" content="2023-12-24T08:00:00-04:00, FC Neftci Baku vs FK Kapaz Ganca in the Azerbaijan Premier League">
                                    <meta itemprop="location" content="Bakcell Arena">
                                    <meta itemprop="Organization" content="Azerbaijan Premier League">
                                    <a rel="nofollow" href="/match-fc-neftci-baku-fk-kapaz-ganca/m2q15ipe842ie76" target="_blank" class="flex items-center justify-center w-1/6 text-gray-800">
                                        <div class="w-full text-right pr-8">
                                            <span class="iconfont icon-lujingbeifen text-xs text-gray-600 transform scale-75"></span>
                                        </div>
                                    </a>
                                </div>

                                <div data-matchstatus="3" itemscope="itemscope" itemtype="http://schema.org/SportsEvent" class="flex text-sm text-gray-800">
                                    <span itemprop="startDate" class="flex items-center justify-center w-1/6">24 Dec 21:30</span>
                                    <a href="/team-zira-fk/m2q15i28l3cm76x" target="_blank" itemprop="homeTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-end text-blue-600">
                                        <span itemprop="name">Zira FK</span>
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/78d040926970a0ccc54c3b1f13a6d568.png!w30" alt="Zira FK" title="Zira FK" class="team-logo ml-3">
                                    </a>
                                    <a itemprop="url" href="/match-zira-fk-qarabag/oj7x9inwmd6c47g" target="_blank" class="flex items-center justify-center w-1/12 text-gray-800">0 - 1</a>
                                    <a href="/team-qarabag/59gklzi8rpc17xd" target="_blank" itemprop="awayTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-start text-blue-600">
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/7f7d00906d511bcf48f9a600580ff953.png!w30" alt="Qarabag" title="Qarabag" class="team-logo mr-3">
                                        <span itemprop="name">Qarabag</span>
                                    </a>
                                    <meta itemprop="name" content="Zira FK vs Qarabag">
                                    <meta itemprop="url" content="https://www.aiscore.com/match-zira-fk-qarabag/oj7x9inwmd6c47g">
                                    <meta itemprop="startDate" content="2023-12-24T10:30:00-04:00">
                                    <meta itemprop="eventStatus" content="https://schema.org/EventScheduled">
                                    <meta itemprop="description" content="2023-12-24T10:30:00-04:00, Zira FK vs Qarabag in the Azerbaijan Premier League">
                                    <meta itemprop="location" content="Zira Olympic Sport Complex">
                                    <meta itemprop="Organization" content="Azerbaijan Premier League">
                                    <a rel="nofollow" href="/match-zira-fk-qarabag/oj7x9inwmd6c47g" target="_blank" class="flex items-center justify-center w-1/6 text-gray-800">
                                        <div class="w-full text-right pr-8">
                                            <span class="iconfont icon-lujingbeifen text-xs text-gray-600 transform scale-75"></span>
                                        </div>
                                    </a>
                                </div>

                                <div data-matchstatus="4" itemscope="itemscope" itemtype="http://schema.org/SportsEvent" class="flex text-sm text-gray-800">
                                    <span itemprop="startDate" class="flex items-center justify-center w-1/6">30 Dec 00:00</span>
                                    <a href="/team-araz-nakhchivan/vmqy9ijxpdi4k9r" target="_blank" itemprop="homeTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-end text-blue-600">
                                        <span itemprop="name">Araz Nakhchivan</span>
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/14c169b16b5ecc4652666219f4e3d157.png!w30" alt="Araz Nakhchivan" title="Araz Nakhchivan" class="team-logo ml-3">
                                    </a>
                                    <a itemprop="url" href="/match-araz-nakhchivan-turan-tovuz/l6kegiwxr1lsv75" target="_blank" class="flex items-center justify-center w-1/12 text-red-600">Postponed</a>
                                    <a href="/team-turan-tovuz/jek33i6pe0bdko2" target="_blank" itemprop="awayTeam" itemscope="itemscope" itemtype="http://schema.org/SportsTeam" class="flex items-center flex-1 justify-start text-blue-600">
                                        <img itemprop="logo" src="https://img0.aiscore.com/football/team/14215ad91a839ba1b4f216001eb02d91.png!w30" alt="Turan Tovuz" title="Turan Tovuz" class="team-logo mr-3">
                                        <span itemprop="name">Turan Tovuz</span>
                                    </a>
                                    <meta itemprop="name" content="Araz Nakhchivan vs Turan Tovuz">
                                    <meta itemprop="url" content="https://www.aiscore.com/match-araz-nakhchivan-turan-tovuz/l6kegiwxr1lsv75/h2h">
                                    <meta itemprop="startDate" content="2023-12-29T13:00:00-04:00">
                                    <meta itemprop="eventStatus" content="https://schema.org/EventScheduled">
                                    <meta itemprop="description" content="2023-12-29T13:00:00-04:00, Araz Nakhchivan vs Turan Tovuz in the Azerbaijan Premier League">
                                    <meta itemprop="location" content="Tovuz City Stadium">
                                    <meta itemprop="Organization" content="Azerbaijan Premier League">
                                    <a rel="nofollow" href="/match-araz-nakhchivan-turan-tovuz/l6kegiwxr1lsv75" target="_blank" class="flex items-center justify-center w-1/6 text-gray-800">
                                        <div class="w-full text-right pr-8">
                                            <span class="iconfont icon-lujingbeifen text-xs text-gray-600 transform scale-75"></span>
                                        </div>
                                    </a>
                                </div>

                            </div>
                            <!---->
                        </div>
                        <div class="myplugins flex items-center justify-center h-full">
                            <div class="text text-center">Add Schedule to your website!</div>
                        </div>

                        <div class="w-full">
                            <div class="mt-8">
                                <div id="standings" class="flex justify-between items-center border-box">
                                <div class="color-p fs-14 font-500 w-o-h" > Standings </div>
                                <div  role="radiogroup" class="el-radio-group customize-radio-group">
                                <label  role="radio" aria-checked="true" tabindex="0" class="el-radio-button el-radio-button--mini is-active">
                                    <input type="radio" tabindex="-1" class="el-radio-button__orig-radio" value="Overall">
                                    <span class="el-radio-button__inner"> All
                                    <!---->
                                    </span>
                                </label>
                                <label  role="radio" tabindex="-1" class="el-radio-button el-radio-button--mini">
                                    <input type="radio" tabindex="-1" class="el-radio-button__orig-radio" value="Home">
                                    <span class="el-radio-button__inner"> Home
                                    <!---->
                                    </span>
                                </label>
                                <label  role="radio" tabindex="-1" class="el-radio-button el-radio-button--mini">
                                    <input type="radio" tabindex="-1" class="el-radio-button__orig-radio" value="Away">
                                    <span class="el-radio-button__inner"> Away
                                    <!---->
                                    </span>
                                </label>
                                </div>
                            </div>
                            <div class="w100" >
                                <div class="border-box">
                                <!---->
                                <div class="table flex-1 fs-12" style="border-top:1px solid #EEEEEE;"  >
                                    <div class="flex fs-12 text-gray-800 h-10" style="background: rgba(244, 245, 248, 1);">
                                        <div class="col border-r flex-4 flex items-center">
                                            <span class="ml-5">#</span>
                                            <span class="pl-8 ml-1">Teams</span>
                                        </div>
                                        <div class="col flex-1.5 pwdl border-r flex items-center">
                                            <span class="flex-1">P</span>
                                            <span class="flex-1">W</span>
                                            <span class="flex-1">D</span>
                                            <span class="flex-1">L</span>
                                        </div>
                                        <div class="col goals flex-0.5 justify-center border-r flex items-center">Goals</div>
                                        <div class="col last-5 flex justify-center border-r items-center relative">
                                            Last 5
                                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANgAAAAbCAYAAAAeXEH3AAAAAXNSR0IArs4c6QAAAupJREFUeAHtnL+LE0EUxy9GE5uAWAinWAg2KjayCYog1wpWCsoVIigkISRgp6BCwD/AwphfpZWFciAERAThtNCYCAp2FlYJIsIVNpeffvdkw+ze7mbTms/CZGbevDfFB7682TdJVlYWeMrl8t4F3HGFwNIT2BOVQD6fz/X7/c1sNrsaNQY/CCw7gVgUABLX+clk8la++9R68Xj8Sq1W+xAlFh8ILDOBuRlM4joynU6fC5ItLvs5LLFt6Li4/9+UTwhAIIhAaAYrlUrJwWCwKYFlnA1isdhE84vNZvO1Y6OHAAT8CYRmMImrZorL3kLzu4jLHyZWCHgJBGYwHQ2LOgo+9gQ8k7jWPTamEIBAAAHfDJbL5S4oUz0yY3Q0/KL5LdPGGAIQCCewK4MVCoWj4/G4I4EdckIlrt9qVr1e/+HY6CEAgfkEXBnMrgxKXBumuLTFWO0a4poPEw8IeAm4MpgukZ/K4brppMz1QIKrmzbGEIBANAIzgUlctxXieu+KtgVeEIBAEIEdgaliuKaK4Rs5xYMcsUMAAosT2HkH01efegr9s3g4ERCAQBiB2RFRWeySsthLOc9sGm+r/QzbgDUIQCCYgCmmFd1/3VdB46HHvaHL5bzHxhQCEIhAwPXO1el03rVardOKO2HEWul0uqe1z4aNIQQgEIGA6x5MJfmp3sduKO6bGaujY0XZ7ZxpYwwBCMwn4DoiOu76Nsfx0Wj0SfMDjk19P5FIWJVKxS6I8EAAAhEIuDKY41+tVr8rm62rTRyb+tXhcPjC/gmLYWMIAQiEEPAVmO3faDReqeBxz4zV/Kx+wvLEtDGGAASCCbiKHF63brf73rKsk7KfMtbOyPZLa/YRkgcCEAghEJjBnJhUKnVT46/O3O6Vye7wlwEmEcYQ8CfgW+TwuhaLxWM6GnZkP6j2UcWOyxQ7vJSYQ2A3gdAjouPebre3MpmMfQ+2nUwmr0pcW84aPQQgAAEIQAACEIDA/0bgLzdDzcHMKKHuAAAAAElFTkSuQmCC" class="left-arrow">
                                        </div>
                                        <div class="col pts flex-0.5 justify-center items-center">Pts</div>
                                    </div>

                                    <div data-team-id="59gklzi8rpc17xd" class="flex fs-12 text-gray-800 h-10 relative">
                                        <div class="flex items-center col h-10 border-r flex-4 overflow-auto">
                                            <a target="_self" href="/team-qarabag/59gklzi8rpc17xd" class="text-gray-800 flex items-center whitespace-nowrap">
                                                <span class="num text-gray-800 flex-shrink-0 bg-transparent ml-4">1</span>
                                                <img src="https://img0.aiscore.com/football/team/7f7d00906d511bcf48f9a600580ff953.png!w40" alt="Qarabag" title="Qarabag" class="ml-1 w-5 flex-shrink-0">
                                                <span class="ml-1 team-name whitespace-nowrap">Qarabag</span>
                                            </a>
                                        </div>
                                        <div class="col flex-1.5 pwdl border-r flex items-center h-10">
                                            <span class="flex-1">36</span>
                                            <span class="flex-1">26</span>
                                            <span class="flex-1">5</span>
                                            <span class="flex-1">5</span>
                                        </div>
                                        <div class="col goals flex-0.5 justify-center border-r flex items-center h-10">97:37</div>
                                        <div class="col last-5 flex justify-around border-r items-center h-10 relative">
                                            <div>
                                                <span arrow-class="popper-arrow">
                                                    <div role="tooltip" id="el-popover-1522" aria-hidden="true" class="el-popover el-popper popover-standings hidden" tabindex="0">
                                                        <span class="text">2024/05/26</span>
                                                        <span>
                                                            <span>2</span> : <span>2</span>
                                                            <span class="ml-3">Araz Nakhchivan</span>
                                                            <span class="ml-1">-</span>
                                                            <span class="ml-1">Qarabag</span>
                                                        </span>
                                                    </div>
                                                    <span class="el-popover__reference-wrapper">
                                                        <span data-id="34kgmizygz3beko" class="num D el-popover__reference" aria-describedby="el-popover-1522" tabindex="0">D</span>
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <span arrow-class="popper-arrow">
                                                    <div role="tooltip" id="el-popover-4927" aria-hidden="true" class="el-popover el-popper popover-standings hidden" tabindex="0">
                                                        <span class="text">2024/05/17</span>
                                                        <span>
                                                            <span>4</span> : <span>3</span>
                                                            <span class="ml-3">Qarabag</span>
                                                            <span class="ml-1">-</span>
                                                            <span class="ml-1">Turan Tovuz</span>
                                                        </span>
                                                    </div>
                                                    <span class="el-popover__reference-wrapper">
                                                        <span data-id="527r3in93n3h47e" class="num W el-popover__reference" aria-describedby="el-popover-4927" tabindex="0">W</span>
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <span arrow-class="popper-arrow">
                                                    <div role="tooltip" id="el-popover-2098" aria-hidden="true" class="el-popover el-popper popover-standings hidden" tabindex="0">
                                                        <span class="text">2024/05/11</span>
                                                        <span>
                                                            <span>0</span> : <span>1</span>
                                                            <span class="ml-3">Zira FK</span>
                                                            <span class="ml-1">-</span>
                                                            <span class="ml-1">Qarabag</span>
                                                        </span>
                                                    </div>
                                                    <span class="el-popover__reference-wrapper">
                                                        <span data-id="jr7owirlyr3igq0" class="num W el-popover__reference" aria-describedby="el-popover-2098" tabindex="0">W</span>
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <span arrow-class="popper-arrow">
                                                    <div role="tooltip" id="el-popover-4665" aria-hidden="true" class="el-popover el-popper popover-standings hidden" tabindex="0">
                                                        <span class="text">2024/05/04</span>
                                                        <span>
                                                            <span>5</span> : <span>0</span>
                                                            <span class="ml-3">Qarabag</span>
                                                            <span class="ml-1">-</span>
                                                            <span class="ml-1">FC Neftci Baku</span>
                                                        </span>
                                                    </div>
                                                    <span class="el-popover__reference-wrapper">
                                                        <span data-id="l6kegiwxrwpfv75" class="num W el-popover__reference" aria-describedby="el-popover-4665" tabindex="0">W</span>
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <span arrow-class="popper-arrow">
                                                    <div role="tooltip" id="el-popover-620" aria-hidden="true" class="el-popover el-popper popover-standings hidden" tabindex="0">
                                                        <span class="text">2024/04/28</span>
                                                        <span>
                                                            <span>1</span> : <span>0</span>
                                                            <span class="ml-3">Standard Sumgayit</span>
                                                            <span class="ml-1">-</span>
                                                            <span class="ml-1">Qarabag</span>
                                                        </span>
                                                    </div>
                                                    <span class="el-popover__reference-wrapper">
                                                        <span data-id="ndqmli2z924crkv" class="num L el-popover__reference" aria-describedby="el-popover-620" tabindex="0">L</span>
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col pts flex-0.5 justify-center h-40">83</div>
                                        </div>
                                        <div data-team-id="m2q15i28l3cm76x" class="row fs-12 color-333" style="height:40px;position:relative;">
                                            <div class="flex align-center col h-40 border-right flex-4 overflow-auto">
                                                <a target="_self" href="/team-zira-fk/m2q15i28l3cm76x" class="color-333 flex align-center w-o-h">
                                                    <span class="num color-333 flex-shrink-0 bg-transparent ml-15">2</span>
                                                    <img src="https://img0.aiscore.com/football/team/78d040926970a0ccc54c3b1f13a6d568.png!w40" alt="Zira FK" title="Zira FK" class="ml-xs w-20 flex-shrink-0" style="display:;">
                                                    <span class="ml-xs team-name w-o-h">Zira FK</span>
                                                </a>
                                            </div>
                                            <div class="col flex-1.5 pwdl border-right h-40">
                                                <span class="flex-1">36</span>
                                                <span class="flex-1 w">16</span>
                                                <span class="flex-1 d">10</span>
                                                <span class="flex-1 l">10</span>
                                            </div>
                                            <div class="col goals flex-0.5 justify-center border-right h-40">33:22</div>
                                            <div class="col last-5 flex justify-around border-right h-40" style="display:;">
                                                <div>
                                                    <span arrow-class="popper-arrow">
                                                        <div role="tooltip" id="el-popover-9979" aria-hidden="true" class="el-popover el-popper popover-standings hidden" tabindex="0">
                                                            <span class="text">2024/05/25</span>
                                                            <span>
                                                                <span>1</span> : <span>0</span>
                                                                <span class="ml-12">Zira FK</span>
                                                                <span class="ml-5">-</span>
                                                                <span class="ml-5">Sabail FC</span>
                                                            </span>
                                                        </div>
                                                        <span class="el-popover__reference-wrapper">
                                                            <span data-id="jek33ivjmvzu9ko" class="num W el-popover__reference" aria-describedby="el-popover-9979" tabindex="0">W</span>
                                                        </span>
                                                    </span>
                                                </div>
                                                <!-- Masukkan entri terakhir lainnya di sini -->
                                            </div>
                                            <div class="col pts flex-0.5 justify-center h-40">58</div>
                                        </div>
                                        <!-- Masukkan entri tim lainnya di sini -->

                                        <div class="col pts flex-0.5 justify-center h-40">58</div>
                                        </div>
                                        <div data-team-id="8lk2di5514a3736" class="row fs-12 color-333" style="height:40px;position:relative;">
                                            <div class="flex align-center col h-40 border-right flex-4 overflow-auto">
                                                <a target="_self" href="/team-sabah-baku/8lk2di5514a3736" class="color-333 flex align-center w-o-h">
                                                    <span class="num color-333 flex-shrink-0 bg-transparent ml-15">3</span>
                                                    <img src="https://img0.aiscore.com/football/team/be41df36cb4153c32d4dcf36489d0b80.png!w40" alt="Sabah Baku" title="Sabah Baku" class="ml-xs w-20 flex-shrink-0" style="display:;">
                                                    <span class="ml-xs team-name w-o-h">Sabah Baku</span>
                                                </a>
                                            </div>
                                            <div class="col flex-1.5 pwdl border-right h-40">
                                                <span class="flex-1">36</span>
                                                <span class="flex-1 w">17</span>
                                                <span class="flex-1 d">7</span>
                                                <span class="flex-1 l">12</span>
                                            </div>
                                            <div class="col goals flex-0.5 justify-center border-right h-40">50:40</div>
                                            <div class="col last-5 flex justify-around border-right h-40" style="display:;">
                                                <div>
                                                    <span arrow-class="popper-arrow">
                                                        <div role="tooltip" id="el-popover-5654" aria-hidden="true" class="el-popover el-popper popover-standings hidden" tabindex="0">
                                                            <span class="text">2024/05/25</span>
                                                            <span>
                                                                <span>0</span> : <span>1</span>
                                                                <span class="ml-12">FC Neftci Baku</span>
                                                                <span class="ml-5">-</span>
                                                                <span class="ml-5">Sabah Baku</span>
                                                            </span>
                                                        </div>
                                                        <span class="el-popover__reference-wrapper">
                                                            <span data-id="69759ilyrl4bgk2" class="num W el-popover__reference" aria-describedby="el-popover-5654" tabindex="0">W</span>
                                                        </span>
                                                    </span>
                                                </div>
                                                <!-- Masukkan entri terakhir lainnya di sini -->
                                            </div>
                                            <div class="col pts flex-0.5 justify-center h-40">83</div>
                                        </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="p-4 bg-black-100 border border-livescore-border rounded-t-lg p-5" >
                    <div class="container-box mb-12 pb-15"  >
                        <div class="title flex justify-between" >
                            <span class="color-p font-500 w-o-h" > Azerbaijan Premier League Top players 23-24 </span>
                            <span class="color-999 fs-12" ></span>
                            <!---->
                        </div>
                        <div class="mt-12"   >
                            <!---->
                            <div class="pl-15 pr-15 fs-12 color-999 flex" >
                            <div class="Goals active" >Goals</div>
                            <div class="Assists ml-15" >Assists</div>
                            </div>
                            <div class="table TopPlayer" >
                            <div class="head flex justify-between align-center color-999 border-box fs-12 pl-15 pr-15" >
                                <div class="col col-5" >#</div>
                                <div class="col flex-1" >Players</div>
                                <div class="col col-20" >Matches</div>
                                <div class="col col-25 white-space-n" >
                                <span >Goals(PK)</span>
                                </div>
                            </div>
                            <div class="body pl-15 pr-15" style="min-height: 569px;" >
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >1</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-juninho/34kgmixg0zt0ko9" class="player-logo f-s-0" >
                                    <img src="https://img0.aiscore.com/football/player/c2047a7d928c8b3cf05578f26e78fbdf.png!w50" alt="Juninho" title="Juninho" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-juninho/34kgmixg0zt0ko9" class="mb-xxs display-block color-333" >Juninho</a>
                                    </div>
                                </div>
                                <div class="col col-20" >33</div>
                                <div class="col col-25" > 18(2) </div>
                                </div>
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >2</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-alexandre-ramalingom/j374oiep01gh3qo" class="player-logo f-s-0" >
                                    <img src="https://img0.aiscore.com/football/player/f5d91716add7f53f0b5723b35013c98e.png!w50" alt="alexandre ramalingom" title="alexandre ramalingom" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-alexandre-ramalingom/j374oiep01gh3qo" class="mb-xxs display-block color-333" >alexandre ramalingom</a>
                                    </div>
                                </div>
                                <div class="col col-20" >35</div>
                                <div class="col col-25" > 15(6) </div>
                                </div>
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >3</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-nariman-akhundzade/jek33iowmngc2ko" class="player-logo f-s-0" >
                                    <img src="https://img0.aiscore.com/football/player/21b7f7f226bf60d28b59bf2a5b569732.png!w50" alt="nariman akhundzade" title="nariman akhundzade" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-nariman-akhundzade/jek33iowmngc2ko" class="mb-xxs display-block color-333" >nariman akhundzade</a>
                                    </div>
                                </div>
                                <div class="col col-20" >30</div>
                                <div class="col col-25" > 11 </div>
                                </div>
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >4</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-oto-john/ndkz6ix8z66cwq3" class="player-logo f-s-0" >
                                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAMAAAC7IEhfAAAAq1BMVEUAAADz+//y+//////z+//y+v/z+v/z+//z+//z+v/0+//z/P/4///z///y+v/c5/T79e7u9v54krz269/m7/nj7vjs9fzf6vbr8fjp8Pfp8vvt6uiDm8G8xdewvNKfsMt8lr7z9fXO2OePpMbu7/Dy7uvn5uemt9Gks8yUqMmZq8jz+Pvc5vDY4u/18On17ubi4uXE0eXw6eLEzNq2xdrY2uDN0t3W09S+ws6rjEyiAAAADnRSTlMAgPML6NnTv6qlclIjFjy9diYAAAH+SURBVDjLnZXpeqsgEEDV7NsgCGLUGNM0a3vb3rZ3ef8nKxBwoPvX80vhMAMIYxQyn05GgyQZjCbTefQhi3gICqoAxTBevKv14gQgF8QicoAk7r31Zn2gXAu8zPOSC/1IoT977cUA3IRxmGEcIA7TjoFKHSGACiIpjP30Y8gJwWio6taxn5fqsRfEYXt6ps6UJMfsM+3ZHn5ihsapklCY2Qn2zZvhV8ssdd5lh37PJuYktx5DanAmvyRfJECEbTywdmus9ZGxKzdpQpOFDUjt4Jo9pNVTs3pI07/s3IUUJuQQA96yVdpxZNQtkMBQnRfIux28qlNkz3gXsoR5NNUDnLhOPWqXSKecRhOQohMbXzxx6JYDk2gExDVssp0vVtkGJzmKBihmWRqQ3duOktBBlKipfiRmYNDLTT4V7zzRT31zH4p3N15qXIxmta6cpR4BvMUE2wPP7MmJdbsBf3uCDQfZ1vuL17ADgL/h+AkNv1m72qe7P2e2NY34Ce2hQLNmhrVpw0OBx8xR/T9uz80/N0E8ZnhwDWWVGa5LgODghleB82JnxUKU3lUILxcVxXJ5fRHV01Lg5QquK5WqV5JH7VVEvRQSr6tXALSnq9Tto/YUBS8EFgAsKbqDBKgEWFK8IiWd55BLLFJh2XtFWPbCQopgIf1Zaf662H/79/ECjIFUYeI1OcEAAAAASUVORK5CYII=" alt="oto john" title="oto john" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-oto-john/ndkz6ix8z66cwq3" class="mb-xxs display-block color-333" >oto john</a>
                                    </div>
                                </div>
                                <div class="col col-20" >33</div>
                                <div class="col col-25" > 10(2) </div>
                                </div>
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >5</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-pedro-nuno/69759i53lwtok23" class="player-logo f-s-0" >
                                    <img src="https://img0.aiscore.com/football/player/10027cbaba5818ae33e247303e5955fb.png!w50" alt="Pedro Nuno" title="Pedro Nuno" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-pedro-nuno/69759i53lwtok23" class="mb-xxs display-block color-333" >Pedro Nuno</a>
                                    </div>
                                </div>
                                <div class="col col-20" >34</div>
                                <div class="col col-25" > 10(3) </div>
                                </div>
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >6</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-tural-bayramov/zrkn6i9v6opu0ql" class="player-logo f-s-0" >
                                    <img src="https://img0.aiscore.com/football/player/388f031a5f4181262500b39efbafef6b.png!w50" alt="Tural Bayramov" title="Tural Bayramov" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-tural-bayramov/zrkn6i9v6opu0ql" class="mb-xxs display-block color-333" >Tural Bayramov</a>
                                    </div>
                                </div>
                                <div class="col col-20" >30</div>
                                <div class="col col-25" > 10(7) </div>
                                </div>
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >7</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-leandro-andrade/oj7x9i6g9deug7g" class="player-logo f-s-0" >
                                    <img src="https://img0.aiscore.com/football/player/0c51bdf5baed27a613ee709dc196ce7f.png!w50" alt="leandro andrade" title="leandro andrade" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-leandro-andrade/oj7x9i6g9deug7g" class="mb-xxs display-block color-333" >leandro andrade</a>
                                    </div>
                                </div>
                                <div class="col col-20" >34</div>
                                <div class="col col-25" > 9 </div>
                                </div>
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >8</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-yassine-benzia/ndqmlizm65fokve" class="player-logo f-s-0" >
                                    <img src="https://img0.aiscore.com/football/player/68501322f957b7b76b339597b2a0e554.png!w50" alt="Yassine Benzia" title="Yassine Benzia" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-yassine-benzia/ndqmlizm65fokve" class="mb-xxs display-block color-333" >Yassine Benzia</a>
                                    </div>
                                </div>
                                <div class="col col-20" >25</div>
                                <div class="col col-25" > 9(1) </div>
                                </div>
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >9</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-osama-khalaila/8lk2di5ev1xto73" class="player-logo f-s-0" >
                                    <img src="https://img0.aiscore.com/football/player/e4f8bccf986c571d045038fe117c91a1.png!w50" alt="osama khalaila" title="osama khalaila" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-osama-khalaila/8lk2di5ev1xto73" class="mb-xxs display-block color-333" >osama khalaila</a>
                                    </div>
                                </div>
                                <div class="col col-20" >30</div>
                                <div class="col col-25" > 9(2) </div>
                                </div>
                                <div class="row flex fs-12 color-333" >
                                <div class="col col-5 color-999" >10</div>
                                <div class="col flex-1 justify-start ml-xxs cur-pointer" >
                                    <a target="_self" href="/player-abdellah-zoubir/zrkn6i9rr9h0qle" class="player-logo f-s-0" >
                                    <img src="https://img0.aiscore.com/football/player/e9a4b445270476200f7e31695b829337.png!w50" alt="Abdellah Zoubir" title="Abdellah Zoubir" >
                                    </a>
                                    <div class="fs-12 ml-xs" >
                                    <a target="_self" href="/player-abdellah-zoubir/zrkn6i9rr9h0qle" class="mb-xxs display-block color-333" >Abdellah Zoubir</a>
                                    </div>
                                </div>
                                <div class="col col-20" >29</div>
                                <div class="col col-25" > 8 </div>
                                </div>
                            </div>
                            </div>
                            <div class="mt-15 fs-12 color-p text-center" >
                            <a target="_self" href="/tournament-azerbaijan-premier-league/2j374oirla4qo6d/stats" class="color-p" >Stats</a>
                            <span class="iconfont icon-lujingbeifen fs-12 cur-pointer" style="color: #0F80DA!important" ></span>
                            </div>
                            <div class="myplugins"  >
                            <div class="text" style="text-align:center;" >Add Top players to your website!</div>
                            <!---->
                            <!---->
                            </div>
                        </div>
                        </div>
                        <!---->
                        <div class="container-box mb-12 pb-24"  >
                        <div class="title flex justify-between" >
                            <span class="color-p font-500 w-o-h" > League Info </span>
                            <span class="color-999 fs-12" ></span>
                            <!---->
                        </div>
                        <div class="LeagueInfo fs-12 pl-15 pr-15 mt-12"   >
                            <div class="o-h team-box" >
                            <a href="/team-qarabag/59gklzi8rpc17xd" class="item flex align-center justify-center flex-col cur-pointer" >
                                <img src="https://img0.aiscore.com/football/team/7f7d00906d511bcf48f9a600580ff953.png!w70" alt="Qarabag" title="Qarabag" class="logo" >
                                <span class="mt-8 fs-14 h-24 w-o-h w-bar-100 text-center" style="line-height: 24px" >Qarabag</span>
                                <span class="color-999" style="margin-top: 1px" > Title holder <span >(10)</span>
                                </span>
                            </a>
                            <a href="/team-qarabag/59gklzi8rpc17xd" class="item flex align-center justify-center flex-col cur-pointer" >
                                <img src="https://img0.aiscore.com/football/team/7f7d00906d511bcf48f9a600580ff953.png!w70" alt="Qarabag" title="Qarabag" class="logo" >
                                <span class="mt-8 fs-14 h-24 w-o-h w-bar-100 text-center" style="line-height: 24px" >Qarabag</span>
                                <span class="color-999" style="margin-top: 1px" > Most title <span >(10)</span>
                                </span>
                            </a>
                            </div>
                            <div class="container-box mt-15" >
                            <div class="font-500" >Most valuable player</div>
                            <div class="player flex  mt-15" >
                                <a href="/player-kei-chinen/g6763i09lrs97ry" class="player-logo cur-pointer" style="background-image:url(https://img0.aiscore.com/football/player/3750eb37adebf662244f18723baf89e0.png!w100);background-size:cover;" ></a>
                                <div class="flex flex-col h-bar-100 ml-xs justify-around flex-1" >
                                <a href="/player-kei-chinen/g6763i09lrs97ry" class="cur-pointer" style="color: #000;" >Kei Chinen</a>
                                <a href="/team-fc-neftci-baku/r8lk2di24wi3736" class="color-999 s-0-85 cur-pointer" style="transform-origin: left;" >FC Neftci Baku</a>
                                </div>
                                <div class="market-value font-500 color-p flex align-center justify-end" >€ 1.4M</div>
                            </div>
                            </div>
                            <!---->
                            <!---->
                            <div class="container-box" >
                            <div class="font-500" >Lower division</div>
                            <a href="/tournament-azerbaijan-first-division/n527r3i9glc17ev" class="match flex mt-15 align-center cur-pointer" >
                                <img src="https://img0.aiscore.com/football/competition/037cb5cd1380d9d8506dec3f712e749f.png!w60" alt="Azerbaijan First Division" title="Azerbaijan First Division" class="match-logo" >
                                <span class="flex flex-col h-bar-100 ml-xs justify-around flex-1" >
                                <span class="color-333" >Azerbaijan First Division</span>
                                </span>
                            </a>
                            </div>
                            <div class="container-box" >
                            <div class="font-500" >Newcomers from lower division</div>
                            <a href="/team-fk-kapaz-ganca/l6kegizro0fg75d" class="match flex mt-12 align-center cur-pointer" >
                                <img src="https://img0.aiscore.com/football/team/6e7d0a85acba4a7748913610852cc9cc.png!w60" alt="FK Kapaz Ganca" title="FK Kapaz Ganca" class="match-logo" >
                                <span class="flex flex-col h-bar-100 ml-xs justify-around flex-1" >
                                <span class="color-333" >FK Kapaz Ganca</span>
                                </span>
                            </a>
                            </div>
                            <div class="container-box" >
                            <div class="font-500 mb-xs" >Facts</div>
                            <div class="flex justify-between Stadium-item" >
                                <div class="color-999" >Division level</div>
                                <div >3</div>
                            </div>
                            <div class="flex justify-between Stadium-item" >
                                <div class="color-999" >Rounds</div>
                                <div >36</div>
                            </div>
                            <div class="flex justify-between Stadium-item" >
                                <div class="color-999" >Players</div>
                                <div >338</div>
                            </div>
                            <div class="flex justify-between Stadium-item" >
                                <div class="color-999" >Foreigners</div>
                                <div >147</div>
                            </div>
                            <!---->
                            <!---->
                            <!---->
                            <!---->
                            <!---->
                            <div class="flex justify-between Stadium-item" >
                                <div class="color-999" >Yellow cards</div>
                                <div >819</div>
                            </div>
                            <div class="flex justify-between Stadium-item" >
                                <div class="color-999" >Red cards</div>
                                <div >36</div>
                            </div>
                            </div>
                        </div>
                        </div>
                </div>

            </div>
    <?php }else{ ?>
    <!-- MAIN View for Overview-->
        <div class="flex-auto">
            <div class="flex border border-livescore-border rounded-t-lg justify-between align-middle uppercase">
                <a href="#">
                    <img src="<?php echo base_url() ?>assets/live-assets/img/live.svg" alt="" class="h-6 ml-5 my-4">
                </a>
                <?php
                    $desired_today = $today; 
                    $desired_today_timestamp = strtotime($desired_today);
                    $dates = [];
                    for ($i = -2; $i <= 2; $i++) {
                        $timestamp = strtotime("$i days", $desired_today_timestamp);
                        $dates[] = [
                            'day_name' => date('D', $timestamp),
                            'day_number' => date('d M', $timestamp),
                            'day_number_Year' => date('d-M-Y', $timestamp),
                            'is_today' => ($i === 0)
                        ];
                    }
                    
                ?>
                <?php foreach ($dates as $date): ?>
                    <a href="<?php echo base_url().$page ?>?<?php if(!$comp == null){ echo 'comp='.$comp.'&';} ?>d=<?php echo $date['day_number_Year'];?>">
                        <div class="flex flex-col text-center text-xxs my-4 <?php echo $date['is_today'] ? 'text-livescore-active font-semibold' : ''; ?>">
                            <span><?php echo htmlspecialchars($date['day_name'], ENT_QUOTES, 'UTF-8'); ?></span>
                            <span><?php echo htmlspecialchars($date['day_number'], ENT_QUOTES, 'UTF-8'); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
                <button id="calendarButton">
                    <img src="<?php echo base_url() ?>assets/live-assets/img/calendar.svg" alt="" class="h-6 mr-5 my-4">
                </button>
            </div>

                <!-- EPL -->
                <div class="h-auto border-x border-livescore-border p-2">
                            
                <?php

                if (isset($match->results) && is_array($match->results)):
                    $foundMatch = false;
                    // var_dump($match->results);

                    foreach ($match->results as $index => $matchs):
                            $foundMatch = true;
                            ?>
                            <div class="flex justify-between">
                                <a href="<?php echo base_url().$page ?>?tournament=<?php echo $matchs->competition_id;?>" target="_blank">
                                    <div class="flex">
                                        <div class="my-auto ml-2">
                                        <?php foreach ($list as $index => $competition){ 
                                            if($competition->id==$matchs->competition_id){
                                        ?>
                                            <img src="<?php echo $competition->logo ?>" alt="" class="h-3 mr-2">
                                        <?php }}?>
                                        </div>
                                        <div class="my-auto ml-1">
                                        <?php foreach ($list as $index => $competition){ 
                                            if($competition->id==$matchs->competition_id){
                                        ?>
                                            <div class="text-sm font-semibold"><?php echo htmlspecialchars($competition->name, ENT_QUOTES, 'UTF-8'); ?></div>
                                        <?php }}?>
                                            <!-- <?php echo htmlspecialchars($matchs->season_id, ENT_QUOTES, 'UTF-8'); ?></span> -->
                                        
                                        </div>
                                    </div>
                                </a>
                                <a href="<?php echo base_url().$page ?>?tournament=<?php echo $matchs->competition_id;?>" target="_blank" class="my-auto mr-2">
                                    <div>
                                        <i class="fa-solid fa-angle-right"></i>
                                    </div>
                                </a>
                            </div>
                            <div class="flex space-x-5 pr-2 py-3 mt-4 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                                <a href="<?php echo base_url().$page ?>?match=<?php echo $matchs->id;?>" target="_blank" class="flex justify-between w-full h-12">
                                    <div class="flex">
                                        <div class="opacity-0 w-1 rounded-r"></div>
                                        <div class="my-auto w-7 ml-5 text-center"><?php echo date('H:m', $matchs->match_time); ?></div>
                                        <div class="ml-5 space-y-1 my-auto">
                                            
                                            <?php foreach ($listteam as $index => $team){ 
                                                if($team->id==$matchs->home_team_id){
                                            ?>
                                            <div class="flex h-5">
                                                <div><img src="<?php echo $team->logo ? $team->logo : $team->country_logo; ?>" alt="" class="w-5 mr-2.5"></div>
                                                <div><?php echo $team->name ? $team->name: $team->short_name; ?></div>
                                                </div>
                                                <?php }}?>
                                            
                                            
                                            <?php foreach ($listteam as $index => $team){ 
                                                if($team->id==$matchs->away_team_id){
                                            ?>
                                            <div class="flex h-5">
                                                <div><img src="<?php echo $team->logo ? $team->logo : $team->country_logo; ?>" alt="" class="w-5 mr-2.5"></div>
                                                <div><?php echo $team->short_name ? $team->name: $team->short_name; ?></div>
                                                </div>
                                                <?php }}?>
                                            
                                        </div>
                                    </div>
                                    <div class="text-center font-bold w-4 space-y-1 my-auto">
                                        <div><?php echo htmlspecialchars($matchs->home_scores[0], ENT_QUOTES, 'UTF-8'); ?></div>
                                        <div><?php echo htmlspecialchars($matchs->away_scores[0], ENT_QUOTES, 'UTF-8'); ?></div>
                                    </div>
                                </a>
                                <div class="my-auto opacity-50">
                                    <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                                </div>
                            </div>
                            <?php
                    endforeach;
                    if (!$foundMatch):
                        ?>
                        <p>No matches found for <?php echo $today;?>.</p>
                        <?php
                    endif;
                else:
                    ?>
                    <p>No competitions found.</p>
                    <?php
                endif;
                ?>

                <!-- <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="bg-livescore-active w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center font-bold text-livescore-active">69'</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/bournemouth.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>AFC Bournemouth</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/brentford.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Brentford</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div>0</div>
                            <div>0</div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="bg-livescore-active w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center font-bold text-livescore-active">69'</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/crystal_palace.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Crystal Palace</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/chelsea.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Chelsea</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div>1</div>
                            <div>1</div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="bg-livescore-active w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center font-bold text-livescore-active">69'</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/fulham.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Fulham</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/newcastle.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Newcastle United</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div>0</div>
                            <div>3</div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="bg-livescore-active w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center font-bold text-livescore-active">69'</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/liverpool.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Liverpool</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/brighton.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Brighton & Hove Albion</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div>1</div>
                            <div>2</div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="bg-livescore-active w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center font-bold text-livescore-active">69'</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/southampton.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Southampton</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/everton.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Everton</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div>1</div>
                            <div>1</div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div> -->
            </div>

            <!-- SERIE A -->
            <!-- <div class="h-auto border border-y-0 border-livescore-border p-2">
                <div class="flex justify-between">
                    <a href="#">
                        <div class="flex">
                            <div class="my-auto ml-2">
                                <img src="<?php echo base_url() ?>assets/live-assets/img/nation/italy.jpg" alt="" class="h-3 mr-2">
                            </div>
                            <div class="my-auto ml-1">
                                <div class="text-sm font-semibold">Serie A</div>
                                <span class="text-xxs">Italy</span>
                            </div>
                        </div>
                    </a>
                    <a href="#" class="my-auto mr-2">
                        <div>
                            <i class="fa-solid fa-angle-right"></i>
                        </div>
                    </a>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-4 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="bg-livescore-active w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center font-bold text-livescore-active">69'</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/empoli.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Empoli</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/acmilan.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>AC Milan</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div>1</div>
                            <div>3</div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="opacity-0 w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center text-xs">17:30</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/lazio.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Lazio</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/spezia.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Spezia</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div></div>
                            <div></div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="opacity-0 w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center text-xs">17:30</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/lecce.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Lecce</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/cremonense.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Cremonense</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div></div>
                            <div></div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="opacity-0 w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center text-xs">17:30</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/sampdoria.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Sampdoria</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/monza.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Monza</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div></div>
                            <div></div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="opacity-0 w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center text-xs">17:30</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/sassuolo.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Sassuolo</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/salernitana.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Salernitana</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div></div>
                            <div></div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
            </div> -->

            <!-- LA LIGA -->
            <!-- <div class="h-auto border border-t-0 rounded-lg rounded-t-none border-livescore-border p-2">
                <div class="flex justify-between">
                    <a href="#">
                        <div class="flex">
                            <div class="my-auto ml-2">
                                <img src="<?php echo base_url() ?>assets/live-assets/img/nation/spain.jpg" alt="" class="h-3 mr-2">
                            </div>
                            <div class="my-auto ml-1">
                                <div class="text-sm font-semibold">LaLiga Santander</div>
                                <span class="text-xxs">Spain</span>
                            </div>
                        </div>
                    </a>
                    <a href="#" class="my-auto mr-2">
                        <div>
                            <i class="fa-solid fa-angle-right"></i>
                        </div>
                    </a>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-4 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="opacity-0 w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center">FT</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/mallorca.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Mallorca</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/barcelona.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Barcelona</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div>0</div>
                            <div>1</div>
                        </div>
                    </a>
                    <div class="my-auto opacity-50">
                        <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="opacity-0 w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center text-xs">17:30</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/espanyol.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Espanyol</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/valencia.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Valencia</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div></div>
                            <div></div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="opacity-0 w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center text-xs">17:30</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/celta_vigo.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Celta Vigo</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/real_betis.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Real Betis</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div></div>
                            <div></div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>
                <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                    <a href="#" class="flex justify-between w-full h-12">
                        <div class="flex">
                            <div class="opacity-0 w-1 rounded-r"></div>
                            <div class="my-auto w-7 ml-5 text-center text-xs">17:30</div>
                            <div class="ml-5 space-y-1 my-auto">
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/girona.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Girona</div>
                                </div>
                                <div class="flex h-5">
                                    <div><img src="<?php echo base_url() ?>assets/live-assets/img/club/real_sociedad.png" alt="" class="w-5 mr-2.5"></div>
                                    <div>Real Sociedad</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center font-bold w-4 space-y-1 my-auto">
                            <div></div>
                            <div></div>
                        </div>
                    </a>
                    <div class="my-auto">
                        <a href="#">
                            <img src="<?php echo base_url() ?>assets/live-assets/img/favourites.svg" alt="" class="h-6 mr-3">
                        </a>
                    </div>
                </div>

            </div> -->
        </div>
                    
        <!-- RIGHT SIDEBAR -->
        <div class="w-72 -mt-11">
            <a href="#">
                <div class="flex h-auto justify-between border border-livescore-border rounded-t-lg p-5">
                    <div class="font-semibold">Featured News</div>
                    <div>
                        <i class="fa-solid fa-angle-right"></i>
                    </div>
                </div>
            </a>
            <div class="h-auto border border-t-0 rounded-lg rounded-t-none border-livescore-border p-2">
            <?php if (isset($listnews) && is_array($listnews)):
                    foreach ($listnews as $index => $news):
                        ?>
                <div class="rounded-lg relative m-1 mb-4 overflow-hidden">
                    <a href="<?php echo $news->link;?>">
                        <img alt="eggs" src="<?php echo $news->image;?>" class="rounded-lg" />
                        <div
                            class="absolute bg-gradient-to-b bg-opacity-60 from-transparent to-black w-full p-4 bottom-0">
                            <div class="flex justify-between font-bold">
                                <p><?php echo $news->title;?>
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach;?>
                <?php endif;?>
            </div>

            <a href="#">
                <div class="flex h-auto justify-between border border-livescore-border rounded-t-lg p-5">
                    <div class="font-semibold">Top Player</div>
                    <div>
                        <i class="fa-solid fa-angle-right"></i>
                    </div>
                </div>
            </a>
            <?php if (isset($listplayer) && is_array($listplayer)):
                    foreach ($listplayer as $index => $player):
                        if($index<=10):
            ?>
                    <div class="flex space-x-5 pr-2 py-3 mt-2 bg-livescore-item rounded-md hover:bg-livescore-item-hover">
                        <a href="#" class="flex justify-between w-full h-12">
                            <div class="flex">
                                <div class="ml-5 space-y-1 my-auto">
                                    <div class="flex h-5">
                                        <div><img src="<?php echo $player->logo ?>" alt="" class="w-5 mr-2.5"></div>
                                        <div><?php echo $player->short_name ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center font-bold w-4 space-y-1 my-auto">
                                <div><?php echo $player->age ?></div>
                            </div>
                        </a>
                        <div class="my-auto">
                            <div><?php echo $player->height ?></div>
                        </div>
                    </div>
                    <?php endif;?>
                <?php endforeach;?>
            <?php endif;?>

            <div class="border border-livescore-border rounded-lg mt-5">
                <img src="<?php echo base_url() ?>assets/live-assets/img/cristianoRonaldo.svg" alt="" class="w-32 mx-auto my-6">
            </div>

        </div>

        <?php } ?>
    </div>

    <!-- FOOTER -->
    <div class="mt-5">
        <div class="text-gray-300 text-xs font-semibold text-center">
            Welcome To LiveScore - Latest Football Live Scores, Results, Fixtures and Tables
        </div>
        <div class="text-gray-300 text-xs text-center mt-1">
            The number one destination for real time scores for Football, Cricket, Tennis, Basketball, Hockey and more.
            LiveScore.com is the go-to destination for latest football scores and news from around the world. Whether
            you’re after today’s results, fixtures or live updates as the goals fly in, all the top leagues and
            competitions are covered in unbeatable detail. We provide fixtures, live scores, results and tables from the
            Premier League, Serie A, LaLiga, the Bundesliga, Ligue 1 and other top tournaments such as the Champions
            League and Europa League. But that’s not all because domestic cup competitions including the world famous FA
            Cup and international tournaments such as the World Cup and Nations League are also at your fingertips. With
            match info and line-ups thrown into the mix, you won’t need to look anywhere else for football stats. Users
            in the UK and Ireland can get stuck in with our live streaming service, offering matches from Serie A, the
            Eredivisie and other top leagues, while anyone in Nigeria can enjoy our net-busting live coverage of the
            Premier League.
        </div>
        <div class="text-gray-300 text-xs text-center mt-1">
            Links: <a href="#" class="underline">English Premier League</a>, <a href="#" class="underline">La Liga</a>,
            <a href="#" class="underline">Serie
                A</a>, <a href="#" class="underline">Bundesliga</a>, <a href="#" class="underline">Ligue 1</a>, <a
                href="#" class="underline">Champions League</a>.
        </div>
        <div class="text-gray-500 text-xs text-center mt-1">
            © 1998-2022 LiveScore
        </div>
        <div class="text-gray-400 text-xxs text-center mt-2">
            <a href="#">Careers</a> | <a href="#">Mobile</a> | <a href="#">Advertise</a> | Faq <a href="#">Contact</a> |
            <a href="#">News Publishers</a> | <a href="#">Privacy Notice</a> | <a href="#">Cookie Policy</a> | <a
                href="#">Terms of Use</a> | <a href="#">Corporate</a>
        </div>
    </div>

    <!-- Modal-->

    <div id="LoginForm" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
        <h2 class="text-2xl font-bold mb-4">Choose Login Method</h2>
        <button id="loginGoogle" class="bg-red-500 text-white px-4 py-2 rounded mb-4 w-full">Login with Google</button>
        <button id="loginGoogle" class="bg-gray-500 text-white px-4 py-2 rounded mb-4 w-full">Login Account</button>
        <div class="lsidDialog__legal">Dengan mengklik pada tombol "lanjutkan dengan" manapun anda telah menyetujui <a href="https://www.livescore.in/id/terms-of-use/" target="_blank">ketentuan penggunaan</a> dan memahami serta menyetujui <a href="https://www.livescore.in/id/privacy-policy/" target="_blank">kebijakan privasi</a> pada situs web kami.</div>
        <br>
            <button id="closeModal" class="bg-red-500 text-white px-4 py-2 rounded">Close</button>
        </div>
    </div>

    <div id="SignupForm" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
            <h2 class="text-2xl font-bold mb-4">Sign Up</h2>
            <form class="signup-form">
                <div class="mb-4">
                    <label for="username" class="block text-sm font-semibold text-gray-700">Username</label>
                    <input type="text" id="username" name="username" class="mt-1 p-2 border rounded-lg w-full" placeholder="Enter your username">
                </div>
                <div class="mb-4">
                    <label for="email" class="block text-sm font-semibold text-gray-700">Email Address</label>
                    <input type="email" id="email" name="email" class="mt-1 p-2 border rounded-lg w-full" placeholder="Enter your email address">
                </div>
                <div class="mb-4">
                    <label for="password" class="block text-sm font-semibold text-gray-700">Password</label>
                    <input type="password" id="password" name="password" class="mt-1 p-2 border rounded-lg w-full" placeholder="Enter your password">
                </div>
                <div class="mb-4">
                    <label for="confirm_password" class="block text-sm font-semibold text-gray-700">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="mt-1 p-2 border rounded-lg w-full" placeholder="Confirm your password">
                </div>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Sign Up</button>
            </form>
            <button id="closeSignupModal" class="bg-red-500 text-white px-4 py-2 rounded mt-4">Close</button>
        </div>
    </div>


     <!-- Modal-->

     <div id="whatNewForm" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
            <h2 class="text-2xl font-bold mb-4">What's New?</h2>
            <p class="text-gray-700 mb-4">Stay updated with the latest features and improvements!</p>
            <ul class="list-disc pl-6">
                <li>Improved user interface</li>
                <li>Enhanced performance</li>
                <li>New customization options</li>
            </ul>
            <button id="closeModal" class="bg-red-500 text-white px-4 py-2 rounded mt-6">Close</button>
        </div>
    </div>

         <!-- Modal-->

         <div id="FaqForm" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
            <div class="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
                <h2 class="text-2xl font-bold mb-4">Frequently Asked Questions (FAQ)</h2>
                <div class="faq-item">
                    <h3 class="text-lg font-semibold mb-2">Question 1: What is Lorem Ipsum?</h3>
                    <p class="text-gray-700">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                </div>
                <div class="faq-item mt-4">
                    <h3 class="text-lg font-semibold mb-2">Question 2: Why do we use it?</h3>
                    <p class="text-gray-700">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                </div>
                <div class="faq-item mt-4">
                    <h3 class="text-lg font-semibold mb-2">Question 3: Where does it come from?</h3>
                    <p class="text-gray-700">Contrary to popular belief, Lorem Ipsum is not simply random text.</p>
                </div>
                <button id="closeFaqModal" class="bg-red-500 text-white px-4 py-2 rounded mt-6">Close</button>
            </div>
        </div>

         <!-- Modal-->

         <div id="ContactUsForm" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
            <div class="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
                <h2 class="text-2xl font-bold mb-4">Contact Us</h2>
                <form class="contact-form">
                    <div class="mb-4">
                        <label for="name" class="block text-sm font-semibold text-gray-700">Your Name</label>
                        <input type="text" id="name" name="name" class="mt-1 p-2 border rounded-lg w-full" placeholder="Enter your name">
                    </div>
                    <div class="mb-4">
                        <label for="email" class="block text-sm font-semibold text-gray-700">Your Email</label>
                        <input type="email" id="email" name="email" class="mt-1 p-2 border rounded-lg w-full" placeholder="Enter your email">
                    </div>
                    <div class="mb-4">
                        <label for="message" class="block text-sm font-semibold text-gray-700">Your Message</label>
                        <textarea id="message" name="message" rows="4" class="mt-1 p-2 border rounded-lg w-full" placeholder="Enter your message"></textarea>
                    </div>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Send Message</button>
                </form>
                <button id="closeContactUsModal" class="bg-red-500 text-white px-4 py-2 rounded mt-4">Close</button>
            </div>
        </div>

     <!-- Modal-->

     <div id="settingForm" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
        <div class="el-dialog__header"><span class="el-dialog__title">Setting</span><button type="button" aria-label="Close" class="el-dialog__headerbtn"><i class="el-dialog__close el-icon el-icon-close"></i></button></div><div class="el-dialog__body"><span  class="topSolid"></span> <div  class="settingsItemBox"><p  class="settingsItemTitle">Language</p> <div  class="languageListBox"><span >English</span> <i  class="iconfont icon-xiala pullIcon"></i> <!----></div></div> <div  class="settingsItemBox settingsItemBoxTop"><p  class="settingsItemTitle">Timezone</p> <div  class="languageListBox"><span >UTC +07:00</span> <i  class="iconfont icon-xiala pullIcon"></i> <!----></div></div> <div  class="settingsItemBox settingsItemBoxTop"><p  class="settingsItemTitle">Odds format</p> <div  class="marginBt"><label  role="radio" aria-checked="true" tabindex="0" class="el-radio is-checked"><span class="el-radio__input is-checked"><span class="el-radio__inner"></span><input type="radio" aria-hidden="true" tabindex="-1" class="el-radio__original" value="De"></span><span class="el-radio__label">EU (1.50)<!----></span></label></div> <div  class="marginBt"><label  role="radio" tabindex="0" class="el-radio"><span class="el-radio__input"><span class="el-radio__inner"></span><input type="radio" aria-hidden="true" tabindex="-1" class="el-radio__original" value="Hk"></span><span class="el-radio__label">HK (0.50)<!----></span></label></div> <div ><label  role="radio" tabindex="0" class="el-radio"><span class="el-radio__input"><span class="el-radio__inner"></span><input type="radio" aria-hidden="true" tabindex="-1" class="el-radio__original" value="Am"></span><span class="el-radio__label">US (-200)<!----></span></label></div></div> <div  class="settingsItemBox settingsItemBoxTop"><p  class="settingsItemTitle">Football alerts settings</p> <div  class="flex flex-col justify-between"><div  role="group" aria-label="checkbox-group" class="el-checkbox-group"><label  class="el-checkbox"><span class="el-checkbox__input"><span class="el-checkbox__inner"></span><input type="checkbox" aria-hidden="false" class="el-checkbox__original" value="1"></span><span class="el-checkbox__label">Fav match only<!----></span></label> <label  class="el-checkbox is-checked"><span class="el-checkbox__input is-checked"><span class="el-checkbox__inner"></span><input type="checkbox" aria-hidden="false" class="el-checkbox__original" value="2"></span><span class="el-checkbox__label">Sound for goal<!----></span></label> <label  class="el-checkbox is-checked"><span class="el-checkbox__input is-checked"><span class="el-checkbox__inner"></span><input type="checkbox" aria-hidden="false" class="el-checkbox__original" value="3"></span><span class="el-checkbox__label">Popup window for goal<!----></span></label></div></div></div></div><!---->
    </div>

    <!-- Modal -->
    <div id="calenderchoose" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
        <div class="flex items-center justify-center min-h-screen">
            <div class="bg-white p-6 rounded-lg shadow-lg">
                <h2 class="text-xl mb-4">Select Date</h2>
                <div class="flex flex-col text-center text-xxs my-6">
                    <?php
                    // Buat array tanggal
                    $dates = [];
                    for ($i = -8; $i <= 8; $i++) {
                        $timestamp = strtotime("$i days");
                        $dates[] = [
                            'day_name' => date('D', $timestamp),
                            'day_number' => date('d M', $timestamp),
                            'date_l' => date('d-M-Y', $timestamp),
                            'is_today' => ($i === 0)
                        ];
                    }
                    ?>

                    <?php foreach ($dates as $date): ?>
                        <a href="<?php echo base_url().$page ?>?d=<?php echo $date['date_l'];?>" class="my-2 <?php echo $date['is_today'] ? 'text-livescore-active font-semibold' : ''; ?>">
                            <div class="flex flex-col">
                                <span><?php echo htmlspecialchars($date['day_name'], ENT_QUOTES, 'UTF-8'); ?></span>
                                <span><?php echo htmlspecialchars($date['day_number'], ENT_QUOTES, 'UTF-8'); ?></span>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
                <button id="closeModal" class="mt-4 bg-red-500 text-white px-4 py-2 rounded">Close</button>
            </div>
        </div>
    </div>


    <script src="<?php echo base_url() ?>assets/live-assets/js/scripts.js"></script>

    <script>
        document.getElementById('openLogin').addEventListener('click', function() {
            document.getElementById('LoginForm').classList.remove('hidden');
        });

        document.getElementById('closeModal').addEventListener('click', function() {
            document.getElementById('LoginForm').classList.add('hidden');
        });

        // JavaScript untuk menampilkan dan menyembunyikan modal
        document.getElementById('calendarButton').addEventListener('click', function() {
            // event.preventDefault();
            document.getElementById('calenderchoose').classList.remove('hidden');
        });

        document.getElementById('closeModal').addEventListener('click', function() {
            document.getElementById('calenderchoose').classList.add('hidden');
        });

        function onSignIn(googleUser) {
        var profile = googleUser.getBasicProfile();
        console.log('ID: ' + profile.getId()); // Don't send this directly to your server!
        console.log('Name: ' + profile.getName());
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
        }

        document.getElementById('loginGoogle').addEventListener('click', function() {
        gapi.auth2.getAuthInstance().signIn().then(onSignIn);
        });

        gapi.load('auth2', function() {
        gapi.auth2.init();
        });



        // // Menutup modal saat klik di luar modal
        // window.onclick = function(event) {
        //     if (event.target == document.getElementById('calenderchoose')) {
        //         document.getElementById('calenderchoose').classList.add('hidden');
        //     }
        // }

        document.addEventListener('DOMContentLoaded', function() {
            const seeAllButton = document.querySelector('#see-all-button');
            const sidebar = document.querySelector('.w-52');

            if (seeAllButton) {
                seeAllButton.addEventListener('click', function() {
                    sidebar.classList.toggle('show-all');
                    if (sidebar.classList.contains('show-all')) {
                        seeAllButton.textContent = 'Minimize List';
                    } else {
                        seeAllButton.textContent = 'See All';
                    }
                });
            }
        });

  </script>

</body>

</html>