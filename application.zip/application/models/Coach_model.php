<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coach_model extends CI_Model {

	public function getID($yah){
		$query = $this->db->where('USERNAME', $yah)->get('admin')->row()->ID_ADMIN;
		return $query;
	}

	public function usernameCheck($input){
		$hue = $this->db->where('USERNAME', $input)->get('admin');
		if($hue->num_rows() == 0){
			return true;
		}else{
			return false;
		}
	}

	public function getList(){
		return $query = $this->db->order_by('id','ASC')->get('coach')->result();
	}

	 // Tambahkan metode untuk mengecek apakah id sudah ada
	 public function id_exists($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('coach'); // sesuaikan nama table jika berbeda
        return $query->num_rows() > 0;
    }

    // Modifikasi metode insert untuk menerima parameter
    public function inserts($data) {
        $this->db->insert('coach', $data); // sesuaikan nama table jika berbeda
    }

	public function generateID(){
		$query = $this->db->order_by('ID_ADMIN', 'DESC')->limit(1)->get('admin')->row('ID_ADMIN');
		$lastNo = (int) substr($query, 2);
		$next = $lastNo + 1;
		$kd = 'AD';
		return $kd.sprintf('%03s', $next);
	}

	public function getPhoto($username){
		return $this->db->where('USERNAME', $username)->get('admin')->row('PHOTO');
	}

	public function getCount(){
		return $this->db->where('ROLE','admin')->from('admin')->count_all_results();
	}

	public function delete($id){
		$this->db->where('ID_ADMIN', $id)->delete('admin');
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function getDetail($id){
		return $this->db->where('ID_ADMIN', $id)->get('admin')->row();
	}

	public function checkAvailability($id){
		$query = $this->db->where('ID_ADMIN', $id)->get('admin');
		if($query->num_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	public function usernameChecks($id){
		$user = $this->db->where('ID_ADMIN', $id)->get('admin')->row('USERNAME');
		if($this->input->post('username') == $user){
			return true;
		}else{
			// $totRow = $this->db->count_all('admin'); //6
			// $query = $this->db->where('USERNAME !=' , $user)->from('admin')->count_all_results(); //5
			// if((int)$query == (int)$totRow - 1){
			// 	return true;
			// }else{
			// 	return false;
			// }

			$get = $this->db->where('USERNAME', $this->input->post('username'))->get('admin');
			if($get->num_rows() > 0){
				return false;
			}else{
				return true;
			}
		}
	}
}

/* End of file Petugas_model.php */
/* Location: ./application/models/Petugas_model.php */