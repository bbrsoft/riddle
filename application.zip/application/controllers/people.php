<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class people extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Player_model');
		$this->load->model('Coach_model');
		$this->load->model('Reffere_model');
		if($this->session->userdata('logged_in') == false){
			redirect('login');
		}
	}

	public function index(){
		if($this->session->userdata('role') == 'superadmin') {
			$data['title'] = 'People';
			$data['primary_view'] = 'master/people_view';
			$data['list'] = $this->Player_model->getList();
			$data['total'] = $this->Player_model->getCount();

			$data['list_Coach'] = $this->Coach_model->getList();
			$data['total_Coach'] = $this->Coach_model->getCount();

			$data['list_Reffere'] = $this->Reffere_model->getList();
			$data['total_Reffere'] = $this->Reffere_model->getCount();

			$this->load->view('template_view', $data);	
		}else{
			$this->load->view('full_401_view');
		}
	}

	public function updatePlayer() {
		if($this->session->userdata('role') == 'superadmin') {
			// URL API
			$url = "https://api.thesports.com/v1/football/player/with_stat/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd";
			
			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			
			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);
			
			// Konversi hasil JSON menjadi objek PHP
			$data = json_decode($response);
			
			// Periksa apakah hasilnya berhasil dikonversi menjadi objek
			if (json_last_error() === JSON_ERROR_NONE) {
				if (isset($data->results) && is_array($data->results)) {
					foreach ($data->results as $player) {
						// Pengecekan apakah id sudah ada di database
						if (!$this->Player_model->id_exists($player->id)) {
							// Persiapkan data untuk diinsert
							$insert_data = array(
								'id' => $player->id,
                                'team_id' => $player->team_id,
                                'name' => $player->name,
                                'short_name' => $player->short_name,
                                'logo' => $player->logo,
                                'national_logo' => $player->national_logo,
                                'birthday' => $player->birthday,
                                'age' => $player->age,
                                'weight' => $player->weight,
                                'height' => $player->height,
                                'country_id' => $player->country_id,
                                'nationality' => $player->nationality,
                                'market_value' => $player->market_value,
                                'market_value_currency' => $player->market_value_currency,
                                'contract_until' => $player->contract_until,
                                'preferred_foot' => $player->preferred_foot,
                                'ability' => json_encode($player->ability),
                                'characteristics' => json_encode($player->characteristics),
                                'position' => $player->position,
                                'positions' => json_encode($player->positions),
                                'updated_at' => date('Y-m-d H:i:s', $player->updated_at)
							);
							// Insert data ke database
							$this->Player_model->inserts($insert_data);
						}
					}
					redirect('people');
				} else {
					// Jika terjadi kesalahan saat decoding JSON, tampilkan pesan kesalahan
					show_error('Failed to decode JSON response', 500);
				}
			}
		} else {
			$this->load->view('full_401_view');
		}
	}

	public function updateCoach() {
		if($this->session->userdata('role') == 'superadmin') {
			// URL API
			$url = "https://api.thesports.com/v1/football/coach/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd";
			
			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			
			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);
			
			// Konversi hasil JSON menjadi objek PHP
			$data = json_decode($response);
			
			// Periksa apakah hasilnya berhasil dikonversi menjadi objek
			if (json_last_error() === JSON_ERROR_NONE) {
				if (isset($data->results) && is_array($data->results)) {
					foreach ($data->results as $coach) {
						// Pengecekan apakah id sudah ada di database
						if (!$this->Coach_model->id_exists($coach->id)) {
							// Persiapkan data untuk diinsert
							$insert_data = array(
								'id' => $coach->id,
                                'team_id' => $coach->team_id,
                                'country_id' => $coach->country_id,
                                'name' => $coach->name,
                                'logo' => $coach->logo,
                                'age' => $coach->age,
                                'birthday' => $coach->birthday,
                                'preferred_formation' => $coach->preferred_formation,
                                'nationality' => $coach->nationality,
                                'updated_at' => date('Y-m-d H:i:s', $coach->updated_at)
							);
							// Insert data ke database
							$this->Coach_model->inserts($insert_data);
						}
					}
					redirect('people');
				} else {
					// Jika terjadi kesalahan saat decoding JSON, tampilkan pesan kesalahan
					show_error('Failed to decode JSON response', 500);
				}
			}
		} else {
			$this->load->view('full_401_view');
		}
	}

	public function updateReferee() {
		if($this->session->userdata('role') == 'superadmin') {
			// URL API
			$url = "https://api.thesports.com/v1/football/referee/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd";
			
			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			
			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);
			
			// Konversi hasil JSON menjadi objek PHP
			$data = json_decode($response);
			
			// Periksa apakah hasilnya berhasil dikonversi menjadi objek
			if (json_last_error() === JSON_ERROR_NONE) {
				if (isset($data->results) && is_array($data->results)) {
					foreach ($data->results as $referee) {
						// Pengecekan apakah id sudah ada di database
						if (!$this->Reffere_model->id_exists($referee->id)) {
							// Persiapkan data untuk diinsert
							$insert_data = array(
								'id' => $referee->id,
                                'name' => $referee->name,
                                'logo' => $referee->logo,
                                'birthday' => $referee->birthday,
                                'country_id' => $referee->country_id,
                                'updated_at' => date('Y-m-d H:i:s', $referee->updated_at)
							);
							// Insert data ke database
							$this->Reffere_model->inserts($insert_data);
						}
					}
					redirect('people');
				} else {
					// Jika terjadi kesalahan saat decoding JSON, tampilkan pesan kesalahan
					show_error('Failed to decode JSON response', 500);
				}
			}
		} else {
			$this->load->view('full_401_view');
		}
	}
	

	
}

/* End of file Petugas.php */
/* Location: ./application/controllers/Petugas.php */