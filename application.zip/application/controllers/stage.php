<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class stage extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Stage_model');
		if($this->session->userdata('logged_in') == false){
			redirect('login');
		}
	}

	public function index(){
		if($this->session->userdata('role') == 'superadmin') {
			$data['title'] = 'Stage';
			$data['primary_view'] = 'master/stage_view';
			$data['list'] = $this->Stage_model->getList();
			$data['total'] = $this->Stage_model->getCount();
			$this->load->view('template_view', $data);	
		}else{
			$this->load->view('full_401_view');
		}
	}

	public function update() {
		if($this->session->userdata('role') == 'superadmin') {
			// URL API
			$url = "https://api.thesports.com/v1/football/stage/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd";
			
			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			
			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);
			
			// Konversi hasil JSON menjadi objek PHP
			$data = json_decode($response);
			
			// Periksa apakah hasilnya berhasil dikonversi menjadi objek
			if (json_last_error() === JSON_ERROR_NONE) {
				if (isset($data->results) && is_array($data->results)) {
					foreach ($data->results as $Stage) {
						// Pengecekan apakah id sudah ada di database
						if (!$this->Stage_model->id_exists($Stage->id)) {
							// Persiapkan data untuk diinsert
							$insert_data = array(
								"id" =>$Stage->id,
								"season_id" =>$Stage->season_id,
								"name" =>$Stage->name,
								"mode" =>$Stage->mode,
								"group_count" =>$Stage->group_count,
								"round_count" =>$Stage->round_count,
								"order" =>$Stage->order,
							);
							// Insert data ke database
							$this->Stage_model->inserts($insert_data);
						}
					}
					redirect('stage');
				} else {
					// Jika terjadi kesalahan saat decoding JSON, tampilkan pesan kesalahan
					show_error('Failed to decode JSON response', 500);
				}
			}
		} else {
			$this->load->view('full_401_view');
		}
	}
	

	
}

/* End of file Petugas.php */
/* Location: ./application/controllers/Petugas.php */