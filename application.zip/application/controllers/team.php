<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class team extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Team_model');
		if($this->session->userdata('logged_in') == false){
			redirect('login');
		}
	}

	public function index(){
		if($this->session->userdata('role') == 'superadmin') {
			$data['title'] = 'Team';
			$data['primary_view'] = 'master/team_view';
			$data['list'] = $this->Team_model->getList();
			$data['total'] = $this->Team_model->getCount();
			$this->load->view('template_view', $data);	
		}else{
			$this->load->view('full_401_view');
		}
	}

	public function update() {
		if($this->session->userdata('role') == 'superadmin') {
			// URL API
			$url = "https://api.thesports.com/v1/football/team/additional/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd";
			
			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			
			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);
			
			// Konversi hasil JSON menjadi objek PHP
			$data = json_decode($response);
			
			// Periksa apakah hasilnya berhasil dikonversi menjadi objek
			if (json_last_error() === JSON_ERROR_NONE) {
				if (isset($data->results) && is_array($data->results)) {
					foreach ($data->results as $Team) {
						// Pengecekan apakah id sudah ada di database
						if (!$this->Team_model->id_exists($Team->id)) {
							// Persiapkan data untuk diinsert
							$insert_data = array(
								"id"=>$Team->id,
								"competition_id"=>$Team->competition_id,
								"country_id"=>$Team->country_id,
								"name"=>$Team->name,
								"short_name"=>$Team->short_name,
								"logo"=>$Team->logo,
								"national"=>$Team->national,
								"country_logo"=>$Team->country_logo,
								"foundation_time"=>$Team->foundation_time,
								"website"=>$Team->website,
								"coach_id"=>$Team->coach_id,
								"venue_id"=>$Team->venue_id,
								"market_value"=>$Team->market_value,
								"market_value_currency"=>$Team->market_value_currency,
								"total_players"=>$Team->total_players,
								"foreign_players"=>$Team->foreign_players,
								"national_players"=>$Team->national_players,
								"updated_at"=>$Team->updated_at
							);
							// Insert data ke database
							$this->Team_model->inserts($insert_data);
						}
					}
					redirect('team');
				} else {
					// Jika terjadi kesalahan saat decoding JSON, tampilkan pesan kesalahan
					show_error('Failed to decode JSON response', 500);
				}
			}
		} else {
			$this->load->view('full_401_view');
		}
	}
	

	
}

/* End of file Petugas.php */
/* Location: ./application/controllers/Petugas.php */