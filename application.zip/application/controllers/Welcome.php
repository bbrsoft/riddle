<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct(){
		parent::__construct();
		// $this->load->model('Setup_model');
		$this->load->model('Competition_model');
		$this->load->model('Team_model');
		$this->load->model('Country_model');
		$this->load->model('Player_model');
		$this->load->model('Coach_model');
		$this->load->model('News_model');
		
		$this->load->helper('url');
        $this->load->library('session');
	}

	public function index(){
		// if($this->Setup_model->checkFirst() == true){
		// 	redirect('setup');
		// }else if ($this->session->userdata('logged_in') == false) {
		// 	redirect('login');
		// }else if ($this->session->userdata('logged_in') == true) {
		// 	redirect('dashboard');
		// }else if ($this->session->userdata('page') == true) {
		

		 // URL API
		 $data['list'] = $this->Competition_model->getList();
		 $data['listteam'] = $this->Team_model->getList();
		 $data['listcountry'] = $this->Country_model->getList();
		 $data['listplayer'] = $this->Player_model->getList();
		 $data['listcoach'] = $this->Coach_model->getList();
		 $data['listnews'] = $this->News_model->getList();
		 
		 $data['page'] = 'welcome';
		 $data['segment'] ='';

		$comp = null;
		$d = null;
		$data['tournamentpage'] = null;
		$data['matchpage'] = null;

		$today = date('Y-m-d');
		$filtered_matches = [];
		

		if (isset($_GET['comp'])) {
			$comp = $_GET['comp'];	
		}

		if (isset($_GET['d'])) {
		    $d = $_GET['d'];
			$timestamp = strtotime($d);
			if ($timestamp === false) {
				echo "Invalid date format.";
			} else {
				$today = date('Y-m-d', $timestamp);
			}
		} else {
			$today = date('Y-m-d');
		}

		if (isset($_GET['tournament'])) {
			$data['tournamentpage'] = $_GET['tournament'];	
		}

		if (isset($_GET['match'])) {
			$data['matchpage'] = $_GET['match'];	
		}
			
		if($data['tournamentpage'] == null && $data['matchpage'] == null){
			$url = "https://api.thesports.com/v1/football/match/recent/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd";

			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);

			// Konversi hasil JSON menjadi objek PHP
			$match_data = json_decode($response);
		}else if($data['tournamentpage'] == null && $data['matchpage'] != null){
			$url = "https://api.thesports.com/v1/football/match/recent/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd&uuid=".$data['matchpage'];

			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);

			curl_close($ch);
			$match_data = json_decode($response);

			
			$url = "https://api.thesports.com/v1/football/match/lineup/detail?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd&uuid=".$data['matchpage'];

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response_lineUp = curl_exec($ch);

			curl_close($ch);

			// Konversi hasil JSON menjadi objek PHP
			$datamatch_data_lineUp = json_decode($response_lineUp);
			$data['match_data_lineUp'] = json_decode($response_lineUp);

			$url = "https://api.thesports.com/v1/football/match/analysis?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd&uuid=".$data['matchpage'];

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response_h2h = curl_exec($ch);

			curl_close($ch);

			// Konversi hasil JSON menjadi objek PHP
			$datamatch_data_h2h = json_decode($response_h2h);
			$data['match_data_h2h'] = json_decode($response_h2h);

			$data['tournament_competition'] ='FIFA';
			$data['home_team'] =' - ';
			$data['home_flag'] =' - ';
			$data['away_team'] =' - ';
			$data['away_flag'] =' - ';
			$data['country_name'] =' - ';
			$data['home_couch'] =' - ';
			$data['home_couch_logo'] =' - ';
			$data['home_couch_country'] =' - ';
			$data['away_couch'] =' - ';
			$data['away_couch_logo'] =' - ';
			$data['away_couch_country'] =' - ';

			if (isset($match_data->results[0])) {
				$result = $match_data->results[0];

				foreach ($data['listcountry'] as $country) {
					if (isset($result->country_id) && $country->id_country == $result->country_id) {
						$data['country_name'] = $country->name;
						break; // keluar dari loop jika sudah ditemukan
					}
				}

				
				foreach ($data['list'] as $competition) {
					if (isset($result->competition_id) && $competition->id == $result->competition_id) {
						$data['tournament_competition'] = $competition->short_name;
						break; // keluar dari loop jika sudah ditemukan
					}
				}

				foreach ($data['listteam'] as $team) {
					if (isset($result->home_team_id) && $team->id == $result->home_team_id) {
						$data['home_team'] = $team->short_name ? $team->short_name : $team->name;
						$data['home_flag'] = $team->logo ? $team->logo : $team->country_logo;
						break; // keluar dari loop jika sudah ditemukan
					}
				}

				foreach ($data['listteam'] as $team) {
					if (isset($result->away_team_id) && $team->id == $result->away_team_id) {
						$data['away_team'] = $team->short_name ? $team->short_name : $team->name;
						$data['away_flag'] = $team->logo ? $team->logo : $team->country_logo;
						break; // keluar dari loop jika sudah ditemukan
					}
				}
			}

			if (isset($datamatch_data_lineUp->results)) {
				$result = $datamatch_data_lineUp->results;

				foreach ($data['listcoach'] as $couch) {
					if (isset($result->couch_id['home']) && $couch->id == $result->couch_id['home']) {
						$data['home_couch'] = $couch->name;
						$data['home_couch_logo'] = $couch->logo;
						foreach ($data['listcountry'] as $country) {
							if($couch->country_id == $country->id_country){
								$data['home_couch_country'] = $country->name;
							}
							break;
						}
						break; // keluar dari loop jika sudah ditemukan
					}
				}

				foreach ($data['listcoach'] as $couch) {
					if (isset($result->couch_id['away']) && $couch->id == $result->couch_id['away']) {
						$data['away_couch'] = $couch->name;
						$data['away_couch_logo'] = $couch->logo;
						foreach ($data['listcountry'] as $country) {
							if($couch->country_id == $country->id_country){
								$data['away_couch_country'] = $country->name;
							}
							break;
						}
						break; // keluar dari loop jika sudah ditemukan
					}
				}
			}

			
		}else if($data['tournamentpage'] != null && $data['matchpage'] == null){
			$url = "https://api.thesports.com/v1/football/competition/additional/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd&uuid=".$data['tournamentpage'];

			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);

			// Konversi hasil JSON menjadi objek PHP
			$match_data = json_decode($response);

			$data['country_compotitiion'] ='';
			$data['flag_country_compotitiion'] ='';
			foreach ($data['listcountry'] as $country) {
				if (isset($result->country_id) && $country->id == $result->country_id) {
					$data['country_compotitiion'] = $country->short_name ? $country->short_name : $country->name;
					$data['flag_country_compotitiion'] = $country->logo ? $country->logo : $country->country_logo;
					break; // keluar dari loop jika sudah ditemukan
				}
			}
			
		}
		// Filter hasil berdasarkan tanggal hari ini
		


		if (isset($match_data->results) && is_array($match_data->results)) {
			foreach ($match_data->results as $match) {
				

				if($data['tournamentpage'] == null && $data['matchpage'] == null){
					$match_date = date('Y-m-d', $match->match_time);
					if($comp!=null){
						if($comp==$match->competition_id){
							if ($match_date == $today) {
								$filtered_matches[] = $match;
							}
						}
					}else{
						if ($match_date == $today) {
							$filtered_matches[] = $match;
						}
					}
				}else if($data['tournamentpage'] == null && $data['matchpage'] != null){
					$filtered_matches[] = $match;
				}else if($data['tournamentpage'] != null && $data['matchpage'] == null){
					$filtered_matches[] = $match;
				}
				
			}
		}

		$data['today'] = $today;

		$data['match'] = (object) ['results' => $filtered_matches];
		if (json_last_error() === JSON_ERROR_NONE) {

			// var_dump($filtered_matches);
			$this->load->view('page_index', $data);
		} else {
			show_error('Failed to decode JSON response', 500);
		}
			
	}

	public function hockey(){
		// if($this->Setup_model->checkFirst() == true){
		// 	redirect('setup');
		// }else if ($this->session->userdata('logged_in') == false) {
		// 	redirect('login');
		// }else if ($this->session->userdata('logged_in') == true) {
		// 	redirect('dashboard');
		// }else if ($this->session->userdata('page') == true) {
		

		 // URL API
		 $data['list'] = $this->Competition_model->getList();
		 $data['listteam'] = $this->Team_model->getList();
		 $data['listcountry'] = $this->Country_model->getList();
		 $data['listplayer'] = $this->Player_model->getList();
		 $data['listcoach'] = $this->Coach_model->getList();
		 $data['listnews'] = $this->News_model->getList();
		 
		 $data['page'] = 'welcome';
		 $data['segment'] ='hockey';

		$comp = null;
		$d = null;
		$data['tournamentpage'] = null;
		$data['matchpage'] = null;

		$today = date('Y-m-d');
		$filtered_matches = [];
		

		if (isset($_GET['comp'])) {
			$comp = $_GET['comp'];	
		}

		if (isset($_GET['d'])) {
		    $d = $_GET['d'];
			$timestamp = strtotime($d);
			if ($timestamp === false) {
				echo "Invalid date format.";
			} else {
				$today = date('Y-m-d', $timestamp);
			}
		} else {
			$today = date('Y-m-d');
		}

		if (isset($_GET['tournament'])) {
			$data['tournamentpage'] = $_GET['tournament'];	
		}

		if (isset($_GET['match'])) {
			$data['matchpage'] = $_GET['match'];	
		}
			
		if($data['tournamentpage'] == null && $data['matchpage'] == null){
			$url = "https://api.thesports.com/v1/football/match/recent/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd";

			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);

			// Konversi hasil JSON menjadi objek PHP
			$match_data = json_decode($response);
		}else if($data['tournamentpage'] == null && $data['matchpage'] != null){
			$url = "https://api.thesports.com/v1/football/match/recent/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd&uuid=".$data['matchpage'];

			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);

			curl_close($ch);
			$match_data = json_decode($response);

			
			$url = "https://api.thesports.com/v1/football/match/lineup/detail?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd&uuid=".$data['matchpage'];

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response_lineUp = curl_exec($ch);

			curl_close($ch);

			// Konversi hasil JSON menjadi objek PHP
			$datamatch_data_lineUp = json_decode($response_lineUp);
			$data['match_data_lineUp'] = json_decode($response_lineUp);

			$url = "https://api.thesports.com/v1/football/match/analysis?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd&uuid=".$data['matchpage'];

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response_h2h = curl_exec($ch);

			curl_close($ch);

			// Konversi hasil JSON menjadi objek PHP
			$datamatch_data_h2h = json_decode($response_h2h);
			$data['match_data_h2h'] = json_decode($response_h2h);

			$data['tournament_competition'] ='FIFA';
			$data['home_team'] =' - ';
			$data['home_flag'] =' - ';
			$data['away_team'] =' - ';
			$data['away_flag'] =' - ';
			$data['country_name'] =' - ';
			$data['home_couch'] =' - ';
			$data['home_couch_logo'] =' - ';
			$data['home_couch_country'] =' - ';
			$data['away_couch'] =' - ';
			$data['away_couch_logo'] =' - ';
			$data['away_couch_country'] =' - ';

			if (isset($match_data->results[0])) {
				$result = $match_data->results[0];

				foreach ($data['listcountry'] as $country) {
					if (isset($result->country_id) && $country->id_country == $result->country_id) {
						$data['country_name'] = $country->name;
						break; // keluar dari loop jika sudah ditemukan
					}
				}

				
				foreach ($data['list'] as $competition) {
					if (isset($result->competition_id) && $competition->id == $result->competition_id) {
						$data['tournament_competition'] = $competition->short_name;
						break; // keluar dari loop jika sudah ditemukan
					}
				}

				foreach ($data['listteam'] as $team) {
					if (isset($result->home_team_id) && $team->id == $result->home_team_id) {
						$data['home_team'] = $team->short_name ? $team->short_name : $team->name;
						$data['home_flag'] = $team->logo ? $team->logo : $team->country_logo;
						break; // keluar dari loop jika sudah ditemukan
					}
				}

				foreach ($data['listteam'] as $team) {
					if (isset($result->away_team_id) && $team->id == $result->away_team_id) {
						$data['away_team'] = $team->short_name ? $team->short_name : $team->name;
						$data['away_flag'] = $team->logo ? $team->logo : $team->country_logo;
						break; // keluar dari loop jika sudah ditemukan
					}
				}
			}

			if (isset($datamatch_data_lineUp->results)) {
				$result = $datamatch_data_lineUp->results;

				foreach ($data['listcoach'] as $couch) {
					if (isset($result->couch_id['home']) && $couch->id == $result->couch_id['home']) {
						$data['home_couch'] = $couch->name;
						$data['home_couch_logo'] = $couch->logo;
						foreach ($data['listcountry'] as $country) {
							if($couch->country_id == $country->id_country){
								$data['home_couch_country'] = $country->name;
							}
							break;
						}
						break; // keluar dari loop jika sudah ditemukan
					}
				}

				foreach ($data['listcoach'] as $couch) {
					if (isset($result->couch_id['away']) && $couch->id == $result->couch_id['away']) {
						$data['away_couch'] = $couch->name;
						$data['away_couch_logo'] = $couch->logo;
						foreach ($data['listcountry'] as $country) {
							if($couch->country_id == $country->id_country){
								$data['away_couch_country'] = $country->name;
							}
							break;
						}
						break; // keluar dari loop jika sudah ditemukan
					}
				}
			}

			
		}else if($data['tournamentpage'] != null && $data['matchpage'] == null){
			$url = "https://api.thesports.com/v1/football/competition/additional/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd&uuid=".$data['tournamentpage'];

			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);

			// Konversi hasil JSON menjadi objek PHP
			$match_data = json_decode($response);

			$data['country_compotitiion'] ='';
			$data['flag_country_compotitiion'] ='';
			foreach ($data['listcountry'] as $country) {
				if (isset($result->country_id) && $country->id == $result->country_id) {
					$data['country_compotitiion'] = $country->short_name ? $country->short_name : $country->name;
					$data['flag_country_compotitiion'] = $country->logo ? $country->logo : $country->country_logo;
					break; // keluar dari loop jika sudah ditemukan
				}
			}
			
		}
		// Filter hasil berdasarkan tanggal hari ini
		


		if (isset($match_data->results) && is_array($match_data->results)) {
			foreach ($match_data->results as $match) {
				

				if($data['tournamentpage'] == null && $data['matchpage'] == null){
					$match_date = date('Y-m-d', $match->match_time);
					if($comp!=null){
						if($comp==$match->competition_id){
							if ($match_date == $today) {
								$filtered_matches[] = $match;
							}
						}
					}else{
						if ($match_date == $today) {
							$filtered_matches[] = $match;
						}
					}
				}else if($data['tournamentpage'] == null && $data['matchpage'] != null){
					$filtered_matches[] = $match;
				}else if($data['tournamentpage'] != null && $data['matchpage'] == null){
					$filtered_matches[] = $match;
				}
				
			}
		}

		$data['today'] = $today;

		$data['match'] = (object) ['results' => $filtered_matches];
		if (json_last_error() === JSON_ERROR_NONE) {

			// var_dump($filtered_matches);
			$this->load->view('page_index', $data);
		} else {
			show_error('Failed to decode JSON response', 500);
		}
			
	}
}
