<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class news extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('News_model');
		if($this->session->userdata('logged_in') == false){
			redirect('login');
		}
	}

	public function index(){
		if($this->session->userdata('role') == 'superadmin') {
			$data['title'] = 'News';
			$data['primary_view'] = 'master/news_view';
			$data['list'] = $this->News_model->getList();
			$data['total'] = $this->News_model->getCount();
			$this->load->view('template_view', $data);	
		}else{
			$this->load->view('full_401_view');
		}
	}

	
}

/* End of file Petugas.php */
/* Location: ./application/controllers/Petugas.php */