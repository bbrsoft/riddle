<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class competition extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Competition_model');
		if($this->session->userdata('logged_in') == false){
			redirect('login');
		}
	}

	public function index(){
		if($this->session->userdata('role') == 'superadmin') {
			$data['title'] = 'Competition';
			$data['primary_view'] = 'master/Competition_view';
			$data['list'] = $this->Competition_model->getList();
			$data['total'] = $this->Competition_model->getCount();
			$this->load->view('template_view', $data);	
		}else{
			$this->load->view('full_401_view');
		}
	}

	public function update() {
		if($this->session->userdata('role') == 'superadmin') {
			// URL API
			$url = "https://api.thesports.com/v1/football/competition/additional/list?user=thehisun&secret=59eae7d0744f85f6577d078ea502fddd";
			
			// Inisialisasi cURL
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			
			// Eksekusi cURL dan simpan hasilnya
			$response = curl_exec($ch);
			curl_close($ch);
			
			// Konversi hasil JSON menjadi objek PHP
			$data = json_decode($response);
			
			// Periksa apakah hasilnya berhasil dikonversi menjadi objek
			if (json_last_error() === JSON_ERROR_NONE) {
				if (isset($data->results) && is_array($data->results)) {
					foreach ($data->results as $Competition) {
						// Pengecekan apakah id sudah ada di database
						if (!$this->Competition_model->id_exists($Competition->id)) {
							// Persiapkan data untuk diinsert
							$insert_data = array(
								"id" => $Competition->id,
								"category_id"=> $Competition->category_id,
								"country_id"=> $Competition->country_id,
								"name"=> $Competition->name,
								"short_name"=> $Competition->short_name,
								"logo" => $Competition->logo,
								"type"=> $Competition->type,
								"cur_season_id"=> $Competition->cur_season_id,
								"cur_stage_id"=> $Competition->cur_stage_id,
								"cur_round"=> $Competition->cur_round,
								"round_count"=> $Competition->round_count,
								'title_holder' => json_encode($Competition->title_holder),
								'most_titles' => json_encode($Competition->most_titles),
								'newcomers' => json_encode($Competition->newcomers),
								'divisions' => json_encode($Competition->divisions),
								'host' => json_encode($Competition->host),
								'primary_color' => $Competition->primary_color,
								"secondary_color"=> $Competition->secondary_color,
								"updated_at"=> $Competition->updated_at
							);
							// Insert data ke database
							$this->Competition_model->inserts($insert_data);
						}
					}
					redirect('country');
				} else {
					// Jika terjadi kesalahan saat decoding JSON, tampilkan pesan kesalahan
					show_error('Failed to decode JSON response', 500);
				}
			}
		} else {
			$this->load->view('full_401_view');
		}
	}
	

	
}

/* End of file Petugas.php */
/* Location: ./application/controllers/Petugas.php */